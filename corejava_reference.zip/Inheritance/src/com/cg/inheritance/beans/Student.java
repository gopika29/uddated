package com.cg.inheritance.beans;

public abstract class Student {
	private int studentId;
	private String firstName,lastName;
	private int sub1Marks,sub2Marks,sub3Marks,sub4Marks;
	private float totalScore;
	public Student() {}
	public Student(int studentId, String firstName, String lastName, int sub1Marks, int sub2Marks, int sub3Marks,
			int sub4Marks) {
		super();
		this.studentId = studentId;
		this.firstName = firstName;
		this.lastName = lastName;
		this.sub1Marks = sub1Marks;
		this.sub2Marks = sub2Marks;
		this.sub3Marks = sub3Marks;
		this.sub4Marks = sub4Marks;
	}
	public int getStudentId() {
		return studentId;
	}
	public void setStudentId(int studentId) {
		this.studentId = studentId;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public int getSub1Marks() {
		return sub1Marks;
	}
	public void setSub1Marks(int sub1Marks) {
		this.sub1Marks = sub1Marks;
	}
	public int getSub2Marks() {
		return sub2Marks;
	}
	public void setSub2Marks(int sub2Marks) {
		this.sub2Marks = sub2Marks;
	}
	public int getSub3Marks() {
		return sub3Marks;
	}
	public void setSub3Marks(int sub3Marks) {
		this.sub3Marks = sub3Marks;
	}
	public int getSub4Marks() {
		return sub4Marks;
	}
	public void setSub4Marks(int sub4Marks) {
		this.sub4Marks = sub4Marks;
	}
	
	public float getTotalScore() {
		return totalScore;
	}
	public void setTotalScore(float totalScore) {
		this.totalScore = totalScore;
	}
	public abstract void calculateScore();
}
