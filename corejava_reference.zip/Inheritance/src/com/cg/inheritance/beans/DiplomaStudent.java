package com.cg.inheritance.beans;

public final class DiplomaStudent extends Student{
	private int practicalMarks;

	public DiplomaStudent(int studentId, String firstName, String lastName, int sub1Marks, int sub2Marks, int sub3Marks,
			int sub4Marks,int practicalMarks) {
		super(studentId, firstName, lastName, sub1Marks, sub2Marks, sub3Marks, sub4Marks);
		this.practicalMarks=practicalMarks;
	}

	public int getPracticalMarks() {
		return practicalMarks;
	}

	public void setPracticalMarks(int practicalMarks) {
		this.practicalMarks = practicalMarks;
	}
	
	public void practicalStatus() {
		System.out.println("practicals completed");
	}

	@Override
	public void calculateScore() {
		setTotalScore(((getSub1Marks()+getSub2Marks()+getSub3Marks()+getSub4Marks())/4)+practicalMarks);
	}
	
	
}
