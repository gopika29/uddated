package com.cg.inheritance.beans;

public final class EngineeringStudent extends Student {
	private int projectMarks,vivaMarks;
	private float finalProjectScore;

	public EngineeringStudent(int studentId, String firstName, String lastName, int sub1Marks, int sub2Marks,
			int sub3Marks, int sub4Marks,int projectMarks,int vivaMarks) {
		super(studentId, firstName, lastName, sub1Marks, sub2Marks, sub3Marks, sub4Marks);
		this.projectMarks=projectMarks;
		this.vivaMarks=vivaMarks;
	}

	public int getProjectMarks() {
		return projectMarks;
	}

	public void setProjectMarks(int projectMarks) {
		this.projectMarks = projectMarks;
	}

	public int getVivaMarks() {
		return vivaMarks;
	}

	public void setVivaMarks(int vivaMarks) {
		this.vivaMarks = vivaMarks;
	}
	public void projectStatus() {
		System.out.println("project completed");
	}

	@Override
	public void calculateScore() {
		finalProjectScore=(projectMarks+vivaMarks)/2;
		setTotalScore(((getSub1Marks()+getSub2Marks()+getSub3Marks()+getSub4Marks())/4)+finalProjectScore);
	}


}
