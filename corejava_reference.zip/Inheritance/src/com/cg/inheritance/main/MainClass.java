package com.cg.inheritance.main;
import com.cg.inheritance.beans.*;
public class MainClass {
	public static void main(String args[]) {
		/*Student s=new Student(120395,"gopi","ankani",98,92,23,92);
		s.calculateScore();
		System.out.println(s.getStudentId()+" "+s.getFirstName()+" "+s.getTotalScore());
		
		EngineeringStudent es=new EngineeringStudent(111, "sadhik", "shaik", 93, 54, 89, 65, 57, 30);
		es.projectStatus();
		es.calculateScore();
		System.out.println(es.getStudentId()+" "+es.getFirstName()+" "+es.getTotalScore());
		
		DiplomaStudent ds=new DiplomaStudent(123, "teja", "hemanth", 67, 56, 56, 89, 35);
		ds.practicalStatus();
		ds.calculateScore();
		System.out.println(ds.getStudentId()+" "+ds.getFirstName()+" "+ds.getTotalScore());*/
		
		Student s;
		
		/*s=new Student(120395,"gopi","ankani",98,92,23,92);
		s.calculateScore();
		System.out.println(s.getStudentId()+" "+s.getFirstName()+" "+s.getTotalScore());*/
		
		s=new EngineeringStudent(111, "sadhik", "shaik", 93, 54, 89, 65, 57, 30);
		EngineeringStudent es=(EngineeringStudent)s;
		es.projectStatus();
		s.calculateScore();
		System.out.println(s.getStudentId()+" "+s.getFirstName()+" "+s.getTotalScore());
		
		s=new DiplomaStudent(123, "teja", "hemanth", 67, 56, 56, 89, 35);
		DiplomaStudent ds=(DiplomaStudent)s;
		ds.practicalStatus();
		s.calculateScore();
		System.out.println(s.getStudentId()+" "+s.getFirstName()+" "+s.getTotalScore());
		
		
		
	}
}
