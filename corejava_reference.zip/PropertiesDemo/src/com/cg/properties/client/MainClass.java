package com.cg.properties.client;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.util.Properties;

public class MainClass {

	public static void main(String[] args) {
		Properties projectProperties=new Properties();
		try {
			projectProperties.load(new FileInputStream(new File(".resources\\project.properties")));
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}

	}

}
