package com.cg.pizzaorder.util;

import java.util.HashMap;
import java.util.Map;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;

public class PizzaOrderUtil {
	//map for orderid as key and pizzaorder as value
	public static Map<Integer,PizzaOrder> pizzaEntry=new HashMap<>();
	//map for cusomerid as key and customer object as value
	public static Map<Integer, Customer> customerEntry=new HashMap<>();

}
