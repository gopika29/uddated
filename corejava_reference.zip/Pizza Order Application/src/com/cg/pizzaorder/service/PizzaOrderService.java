package com.cg.pizzaorder.service;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.dao.IPizzaOrderDAO;
import com.cg.pizzaorder.dao.PizzaOrderDAO;
import com.cg.pizzaorder.exception.PizzaException;

public class PizzaOrderService implements IPizzaOrderService{
	IPizzaOrderDAO iPizzaOrderDAO=new PizzaOrderDAO();
	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		//validation for mobile
		if(validationforMobileNumber(customer.getPhone())==false)throw new PizzaException("mobile number is not valid");
		iPizzaOrderDAO.placeOrder(customer, pizza);
		pizza.setCustomerId(customer.getCustomerId());
		return pizza.getOrderId();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderId) throws PizzaException {
		PizzaOrder pizzaOrder=iPizzaOrderDAO.getOrderDetails(orderId);
		if(pizzaOrder==null)throw new PizzaException("order details not found for this order id");
		pizzaOrder.setTotalPrice(calculatePizzaPrice(orderId, pizzaOrder.getPizzaType()));
		return pizzaOrder;
	}

	public boolean validationforMobileNumber(String mobile) {
		String pattern="\\d+";
		if(mobile.length()==10&&mobile.matches(pattern))
			return true;
		return false;
	}
	
	public int calculatePizzaPrice(int orderId,String type)throws PizzaException{
		int price=0;
		if(type.equals("Capsicum")) 
			price=350+30;
		else if(type.equals("Mushroom"))
			price=350+50;
		else if(type.equals("Jalapeno"))
			price= 350+70;
		else if(type.equals("Paneer"))
			price= 350+85;
		return price;
	}

}
