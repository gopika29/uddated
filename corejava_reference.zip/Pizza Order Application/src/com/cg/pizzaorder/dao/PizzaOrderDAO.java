package com.cg.pizzaorder.dao;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.util.PizzaOrderUtil;

public class PizzaOrderDAO implements IPizzaOrderDAO{

	@Override
	public int placeOrder(Customer customer, PizzaOrder pizza) throws PizzaException {
		pizza.setOrderId((int) Math.random()+1000);
		customer.setCustomerId((int) Math.random()+100);
		PizzaOrderUtil.pizzaEntry.put(pizza.getOrderId(), pizza);
		PizzaOrderUtil.customerEntry.put(customer.getCustomerId(), customer);
		return pizza.getOrderId();
	}

	@Override
	public PizzaOrder getOrderDetails(int orderid) throws PizzaException {
		return PizzaOrderUtil.pizzaEntry.get(orderid);
	}

}
