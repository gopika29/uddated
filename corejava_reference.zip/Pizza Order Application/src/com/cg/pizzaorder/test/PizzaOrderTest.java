package com.cg.pizzaorder.test;

import static org.junit.Assert.*;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.pizzaorder.bean.Customer;
import com.cg.pizzaorder.bean.PizzaOrder;
import com.cg.pizzaorder.exception.PizzaException;
import com.cg.pizzaorder.service.IPizzaOrderService;
import com.cg.pizzaorder.service.PizzaOrderService;
import com.cg.pizzaorder.util.PizzaOrderUtil;


public class PizzaOrderTest {
	public static IPizzaOrderService pizzaOrderService;
	@BeforeClass
	public static void setUpTestEnv() {
		pizzaOrderService=new PizzaOrderService();
	}

	@Before
	public void setUpTestData() {
		PizzaOrder pizzaOrder=new PizzaOrder(101, 1200, "Mushroom");
		Customer customer=new Customer(1200, "John", "Dallas", "9768587350");
		Customer customer1=new Customer(123,"gs","dh","ad23");
		PizzaOrderUtil.customerEntry.put(customer.getCustomerId(),customer);
		PizzaOrderUtil.customerEntry.put(customer1.getCustomerId(),customer1);
		PizzaOrderUtil.pizzaEntry.put(pizzaOrder.getOrderId(), pizzaOrder);
	}
	@Test(expected=PizzaException.class)
	public void TestForInValidDataForplaceOrder(Customer customer, PizzaOrder pizza) throws PizzaException{
		PizzaOrder pizzaOrder=new PizzaOrder(101, 1200, "Mushroom");
		Customer customer1=new Customer(123,"gs","dh","ad23");
		pizzaOrderService.placeOrder(customer1, pizzaOrder);
	}
	@Test
	public void TestForValidDataForplaceOrder(Customer customer, PizzaOrder pizzaOrder) throws PizzaException{
		pizzaOrderService.placeOrder(new Customer("gopi", "ap", "23793"),new PizzaOrder("Mushroom"));
		Assert.assertEquals((int)Math.random(), pizzaOrder.getOrderId());
	}
	
	@Test
	public void TestForGetOrderDetailsForValidId() throws PizzaException{
		
		pizzaOrderService.getOrderDetails(101);
	}
	@After
	public void tearDownTestData() {
		PizzaOrderUtil.customerEntry.clear();
		PizzaOrderUtil.pizzaEntry.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		pizzaOrderService=null;
	}
}
