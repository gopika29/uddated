package com.cg.functionalinterfaces;
@FunctionalInterface
public interface FunctionalInterface1 {
	void greetUser(String firstName,String lastName);
}
