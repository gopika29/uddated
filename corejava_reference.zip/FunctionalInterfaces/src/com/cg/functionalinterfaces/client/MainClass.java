package com.cg.functionalinterfaces.client;

import com.cg.functionalinterfaces.FunctionalInterface1;
import com.cg.functionalinterfaces.FunctionalInterface2;
import com.cg.functionalinterfaces.FunctionalInterface3;
import com.cg.functionalinterfaces.FunctionalInterface4;
import com.cg.functionalinterfaces.WorkService;

public class MainClass {

	public static void main(String[] args) {
		FunctionalInterface1 ref1=(firstName,lastName)->System.out.println("hello "+firstName+" "+lastName);
		ref1.greetUser("gopika", "ankani");
		
		FunctionalInterface2 ref2=(a,b)->a+b;
		System.out.println(ref2.add(100, 200));
		
		FunctionalInterface3 ref3=(str)->str.toUpperCase();
		System.out.println(ref3.toUpper("gopika"));
		
		FunctionalInterface4 ref4=(a,b)->a>b?a:b;
		System.out.println(ref4.greaterNumber(30, 40));
		
		callForWork(()->System.out.println("dong someWork"));
	}
	private static void callForWork(WorkService service) {
		service.doSomeWork();
	}

}
