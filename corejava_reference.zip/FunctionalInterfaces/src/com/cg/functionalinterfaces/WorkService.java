package com.cg.functionalinterfaces;
@FunctionalInterface
public interface WorkService {
	void doSomeWork();
}
