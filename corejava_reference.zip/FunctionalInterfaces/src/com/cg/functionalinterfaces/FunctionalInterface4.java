package com.cg.functionalinterfaces;
@FunctionalInterface
public interface FunctionalInterface4 {
	int greaterNumber(int a,int b);
}
