package com.cg.functionalinterfaces;
@FunctionalInterface
public interface FunctionalInterface3 {
	String toUpper(String str);
}
