package com.cg.inheritance.beans;

public final class Devloper extends PEmployee{
	private int incentives,noOfProjectsDone;

	
	public Devloper(int employeeId, int basicSalary, String firstName, String lastName,int noOfProjectsDone) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfProjectsDone=noOfProjectsDone;
		
	}

	public int getIncentives() {
		return incentives;
	}

	public void setIncentives(int incentives) {
		this.incentives = incentives;
	}

	public int getNoOfProjectsDone() {
		return noOfProjectsDone;
	}

	public void setNoOfProjectsDone(int noOfProjectsDone) {
		this.noOfProjectsDone = noOfProjectsDone;
	}
	
	public void developProject() {
		System.out.println("project has completed");
	}

	@Override
	public void calculateSalary() {
		incentives=noOfProjectsDone*2000;
		super.calculateSalary();
		setTotalSalary(getTotalSalary()+incentives);
	}

	@Override
	public String toString() {
		return super.toString()+",incentives=" + incentives + ", noOfProjectsDone=" + noOfProjectsDone;
	}
	
	
	
	
}
