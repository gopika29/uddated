package com.cg.inheritance.beans;

public final class Sales extends PEmployee{
	private int comission,noOfSales;

	public Sales(int employeeId, int basicSalary, String firstName, String lastName,int noOfSales) {
		super(employeeId, basicSalary, firstName, lastName);
		this.noOfSales=noOfSales;
	}

	public int getComission() {
		return comission;
	}

	public void setComission(int comission) {
		this.comission = comission;
	}

	public int getNoOfSales() {
		return noOfSales;
	}

	public void setNoOfSales(int noOfSales) {
		this.noOfSales = noOfSales;
	}
	
	public void salesDone() {
		System.out.println("sales completed");
	}
	
	public void calculateSalary() {
		comission=noOfSales*100;
		super.calculateSalary();
		setTotalSalary(getTotalSalary()+comission);
	}

	@Override
	public String toString() {
		return super.toString()+",comission=" + comission + ", noOfSales=" + noOfSales;
	}
	
	

}
