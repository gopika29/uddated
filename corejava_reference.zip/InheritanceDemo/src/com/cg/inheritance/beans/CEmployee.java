package com.cg.inheritance.beans;

public final class CEmployee extends Employee{
private int hrs,valuablePay;



public CEmployee(int employeeId, String firstName, String lastName,int hrs) {
	super(employeeId, firstName, lastName);
	this.hrs=hrs;
}

public int getHrs() {
	return hrs;
}

public void setHrs(int hrs) {
	this.hrs = hrs;
}




public void contractSign() {
	System.out.println("contract signed");
}

public void calculateSalary() {
	valuablePay=hrs*1000;
	this.setTotalSalary(valuablePay);
	
}

@Override
public String toString() {
	return super.toString()+",hrs=" + hrs + ", valuablePay=" + valuablePay;
}



}
