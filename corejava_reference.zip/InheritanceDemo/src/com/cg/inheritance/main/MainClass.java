package com.cg.inheritance.main;
import com.cg.inheritance.beans.*;
public class MainClass {

	public static void main(String[] args) {
		/*Employee emp=new Employee(111,30000,"gopi","ankani");
		emp.calculateSalary();
		System.out.println(emp.getEmployeeId()+" "+emp.getTotalSalary());

		PEmployee pemp=new PEmployee(112,45543,"teja","hemanth");
		pemp.calculateSalary();
		System.out.println(pemp.getEmployeeId()+" "+pemp.getTotalSalary());

		CEmployee cemp=new CEmployee(113,"raja","sekhar",300);
		cemp.contractSign();
		cemp.calculateSalary();
		System.out.println(cemp.getEmployeeId()+" "+cemp.getTotalSalary());

		Devloper devEmp=new Devloper(114, 40000, "sadhik","shaik", 3);
		devEmp.developProject();
		devEmp.calculateSalary();
		System.out.println(devEmp.getEmployeeId()+" "+devEmp.getTotalSalary());

		Sales semp=new Sales(115, 40000, "nani","shaik", 50);
		semp.salesDone();
		semp.calculateSalary();
		System.out.println(semp.getEmployeeId()+" "+semp.getTotalSalary());*/

		Employee emp;
		
		emp=new PEmployee(112,45543,"teja","hemanth");
		emp.calculateSalary();
		System.out.println(emp.toString());
		//System.out.println(emp.getEmployeeId()+" "+emp.getTotalSalary());
		
		emp=new CEmployee(113,"raja","sekhar",300);
		CEmployee cemp=(CEmployee)emp;
		cemp.contractSign();
		emp.calculateSalary();
		System.out.println(emp.toString());
		//System.out.println(emp.getEmployeeId()+" "+emp.getTotalSalary());
		
		emp=new Devloper(114, 40000, "sadhik","shaik", 3);
		Devloper devEmp=(Devloper)emp;
		devEmp.developProject();
		emp.calculateSalary();
		System.out.println(emp.toString());
		//System.out.println(emp.getEmployeeId()+" "+emp.getTotalSalary());
		
		emp=new Sales(115, 40000, "nani","shaik", 50);
		Sales semp=(Sales)emp;
		semp.salesDone();
		emp.calculateSalary();
		System.out.println(emp.toString());
		//System.out.println(emp.getEmployeeId()+" "+emp.getTotalSalary());


	}

}
