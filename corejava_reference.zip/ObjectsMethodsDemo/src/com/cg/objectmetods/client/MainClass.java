package com.cg.objectmetods.client;

import com.cg.objectmetods.beans.Address;
import com.cg.objectmetods.beans.Associate;

public class MainClass {

	public static void main(String[] args) {
		Associate associate1=new Associate(111, 30000, "gopi", "ankani",new Address(1234, "w.g", "andhra"));
		Associate associate2=new Associate(111, 30000, "gopi", "ankani",new Address(1234, "w.g", "andhra"));
		if(associate1==associate2)
			System.out.println("same references");
		else
			System.out.println("not same references");
		if(associate1.equals(associate2))
			System.out.println("same data");
		else
			System.out.println("not same data");
	}

}
