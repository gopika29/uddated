import com.cg.threaddemo.evenodd.EvenOddUsingThreads;
import com.cg.threaddemo.runnableresource.RunnableResource;

public class MainClass {

	public static void main(String[] args) {
		/*RunnableResource runnableResource=new RunnableResource();
		Thread th1=new Thread(runnableResource, "th1");
		Thread th2=new Thread(runnableResource, "th2");
		th1.start();
		th2.start();*/
		/*EvenOddUsingThreads evenOdd=new EvenOddUsingThreads();
		Thread th1=new Thread(evenOdd, "th1");
		Thread th2=new Thread(evenOdd, "th2");
		th1.start();
		th2.start();*/
		/*Runnable runnableResource=()->{
			for (int i = 1; i <= 10; i++)
				System.out.println("Tick " + i);
		};
		Thread th1=new Thread(runnableResource);
		th1.start();
		
		Thread th2=new Thread(()->{
			for (int i = 1; i <= 10; i++)
				System.out.println("Tick " + i);
		});
		th2.start();*/
	
		
		new Thread(()->{
			for (int i = 1; i <= 10; i++)
				System.out.println("Tick " + i);
		}).start();
	}

}
