package com.cg.threaddemo.evenodd;
public class EvenOddUsingThreads implements Runnable{

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		try {
			if (t.getName().equals("th1")) {
				for (int i = 1; i <= 100; i++) {
					if (i % 2 == 0)
						System.out.println("even no " + i);
				} 
			}
			else if (t.getName().equals("th2")) {
				Thread.sleep(100);
				for (int i = 1; i <= 100; i++) {
					if (i % 2 != 0)
						System.out.println("odd no " + i);
				} 
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		
	}

}
