package com.cg.threaddemo.mythread;

public class MyThread extends Thread{
	
	public void run() {
		if (this.getName().equals("th1")) {
			for (int i = 1; i <= 10; i++) {
				System.out.println("Tick " + i + this.getName());
			} 
		}
		if (this.getName().equals("th2")) {
			for (int i = 1; i <= 10; i++) {
				System.out.println("Tick " + i + this.getName());
			} 
		}
	}

}
