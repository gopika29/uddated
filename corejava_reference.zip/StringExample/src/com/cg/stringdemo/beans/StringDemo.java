package com.cg.stringdemo.beans;

public class StringDemo {

	public static void main(String[] args) {
		int num1=10,num2=12;
		String str1="gopika",str2="gopika",str=null;
		String str3=new String("java");
		String str4=new String("  java      Develper	");
		
		System.out.println(str1==str2);
		System.out.println(str1.equals(str2));
		
		System.out.println(str3==str4);
		System.out.println(str3.equals(str4));
		
		System.out.println("java"==str3);
		System.out.println(str3.equals("java"));
		
		StringBuffer sb1=new StringBuffer(str3);
		StringBuilder sb2=new StringBuilder("    java    developer   ");//we can StringBuilder(); or we can give size of string StringBuilder(50)
		
		System.out.println(sb1+" "+sb2);
		System.out.println(str1.charAt(5));
		System.out.println(str1.indexOf("k"));
		System.out.println(sb1.substring(2)+"\n"+str2.substring(0,4));
		//System.out.println(sb2.trim()); @we can't use trim function on either stringbuffer or stringbuilder
		System.out.println(str4+"\n"+str4.trim());//trim fn won't work for stringbuffer or stringbuilder
		System.out.println(str4.replace("java", "full Stack")+"\n"+str4); //replace method is temporary change it won't affect the string object
		System.out.println(sb1.length());
		System.out.println(str3.startsWith("j")+"\n"+str4.startsWith("java",2));
		System.out.println(str3.endsWith("a"));//endsWith accept only one argument and can't apply on stringbuffer or stringbuilder
		System.out.println(str4.trim().startsWith("java")+"\n"+str3.substring(0,2).startsWith("j"));//method chaining
		System.out.println(str+str1+10+12+"\n"+str1+(num1+num2)+str2+"\n"+num1+num2+str2);
		System.out.println(str1.substring(2).equals(str2.substring(2)));
		System.out.println(str1.substring(2)==str2.substring(2));
		System.out.println(sb2.append(str1));//we can use append(str,int,int) and these are permanent changes
		System.out.println(sb2.insert(1, str2));
		System.out.println(sb2.delete(1, 7)+"\n"+sb2.deleteCharAt(9)+"\n"+sb2.reverse()+"\n"+sb2.replace(0, 4, str3)+"\n"+sb1.subSequence(0, 4));
/*all functions which works for stringbuilder can work for stringbuffer one difference we can't access from multiplethreads in stringbuilder
		(non-synchronization).we can access stringbuffer from multiple threads(synchronization)*/
	}

	

}
