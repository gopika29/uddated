package com.cg.calculator.test;

import static org.junit.Assert.*;

import org.junit.AfterClass;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.calculator.Services.MathServices;
import com.cg.calculator.Services.MathServicesImpl;
import com.cg.calculator.exceptions.InvalidNumberRangeException;

import org.junit.Assert;

public class MathServicesTest {
	private static MathServices mathservices;
	private int firstInvalidNumber,secondInvalidNumber,firstValidNumber,secondValidNumber;
	@BeforeClass
	public static void setUpTestEnv() {
		mathservices=new MathServicesImpl();
	}
	@Before
	public void setUpTestData() {
		firstInvalidNumber=-100;
		firstValidNumber=100;
		secondInvalidNumber=-200;
		secondValidNumber=200;
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForFirstInvalidNumber() throws InvalidNumberRangeException{
		mathservices.add(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testAddForSecondInvalidNumber() throws InvalidNumberRangeException{
		mathservices.add(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testAddForBothValidNumbers() throws InvalidNumberRangeException {
		int expectedAns=300;
		int actualAns=mathservices.add(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForFirstInvalidNumber() throws InvalidNumberRangeException{
		mathservices.sub(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testSubForSecondInvalidNumber() throws InvalidNumberRangeException{
		mathservices.sub(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testSubForBothValidNumbers() throws InvalidNumberRangeException {
		int expectedAns=-100;
		int actualAns=mathservices.sub(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	@Test(expected=InvalidNumberRangeException.class)
	public void testMultiForFirstInvalidNumber() throws InvalidNumberRangeException{
		mathservices.multi(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testMultiForSecondInvalidNumber() throws InvalidNumberRangeException{
		mathservices.multi(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testMutliForBothValidNumbers() throws InvalidNumberRangeException {
		int expectedAns=20000;
		int actualAns=mathservices.multi(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForFirstInvalidNumber() throws InvalidNumberRangeException{
		mathservices.div(firstInvalidNumber, secondValidNumber);
	}
	
	@Test(expected=InvalidNumberRangeException.class)
	public void testDivForSecondInvalidNumber() throws InvalidNumberRangeException{
		mathservices.div(firstValidNumber, secondInvalidNumber);
	}
	
	@Test
	public void testDivForBothValidNumbers() throws InvalidNumberRangeException {
		int expectedAns=0;
		int actualAns=mathservices.div(firstValidNumber, secondValidNumber);
		Assert.assertEquals(expectedAns, actualAns);
	}
	
	
	@AfterClass
	public static void removeTestEnv() {
		mathservices=null;
	}
}
