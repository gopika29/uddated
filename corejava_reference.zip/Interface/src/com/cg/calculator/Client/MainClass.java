package com.cg.calculator.Client;

import java.util.*;

import com.cg.calculator.Services.MathServices;
import com.cg.calculator.Services.MathServicesImpl;
import com.cg.calculator.exceptions.InvalidNumberRangeException;

public class MainClass {

	public static void main(String[] args) {
		/*MathServices mathServices=new MathServicesImpl();
		System.out.println(mathServices.add(25, 5));
		System.out.println(mathServices.sub(25, 5));
		System.out.println(mathServices.multi(25, 5));
		System.out.println(mathServices.div(25, 5));
		MathServicesImpl s=(MathServicesImpl)mathServices;
		s.serviceStatus();*/
		try {
			Scanner input=new Scanner(System.in);
			System.out.print("enter number1: ");
			int n1=input.nextInt();
			System.out.print("enter number2: ");
			int n2=input.nextInt();
			MathServices mathServices=new MathServicesImpl();
			System.out.println(mathServices.add(n1,n2));
			System.out.println(mathServices.sub(n1,n2));
			System.out.println(mathServices.multi(n1,n2));
			System.out.println(mathServices.div(n1,n2));
			
		}catch (ArithmeticException e) {
			System.err.println(e.getMessage()+" "+"enter second number other than o");
		}
		catch (InputMismatchException e) {
			System.err.println(e.getMessage()+" "+"enter numbers only");
		}
		catch (Exception e) {
			System.err.println(e.getMessage());
		}
	}

}
