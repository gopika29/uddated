package com.cg.lab2.service;

import com.cg.lab2.exception.NameNullException;

public class NameValidation {
	public static boolean nameValidation(String firstName,String lastName) throws NameNullException {
		if(firstName.equals(null)||lastName.equals(null))throw new NameNullException("name should not be empty");
		else return true;
	}
}
