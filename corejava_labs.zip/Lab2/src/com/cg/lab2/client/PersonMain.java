package com.cg.lab2.client;

import com.cg.lab2.bean.Gender;
import com.cg.lab2.bean.Person;
import com.cg.lab2.service.NameValidation;

public class PersonMain {
	public static void main(String args[]) {
		try {
			Person person=new Person("gopi", "ankani", Gender.Female, 21, 42);
			System.out.println("Person Details\n____________________________");
			System.out.println("First Name: "+person.getFirstName()+"\nLast Name: "+person.getLastName()
			+"\nGender: "+person.getGender()+"\nAge: "+person.getAge()+"\nWeight: "+person.getWeight());
			person=new Person("gopi", "ankani", Gender.Female, 21, 42, 88885555);
			//lab6.1
			if(NameValidation.nameValidation(person.getFirstName(), person.getLastName()))
				System.out.println("details inserted successful");
			System.out.println(person.toString());
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
}
