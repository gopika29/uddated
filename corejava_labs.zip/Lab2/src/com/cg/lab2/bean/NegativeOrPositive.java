package com.cg.lab2.bean;

public class NegativeOrPositive {
	public static String checkingForSign(int num) {
		if(num<0) return "negative";
		else return "positive";
	}

}