package com.cg.lab2.bean;

public enum Gender {
	Female,Male;
}
