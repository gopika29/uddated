package com.cg.files.bean;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.Scanner;

public class EvenOddFromFileUsingScanner {
	public static void evenOdd(File file) throws FileNotFoundException {
		Scanner read = new Scanner (file);
		int c;
		while(read.hasNextLine()) {
			c=read.useDelimiter(",").nextInt();
			if(c%2==0) 
				System.out.println(c+"\t");
		}
	}
}
