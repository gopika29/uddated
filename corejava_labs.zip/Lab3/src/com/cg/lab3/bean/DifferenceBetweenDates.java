package com.cg.lab3.bean;

import java.time.LocalDate;
import java.time.Period;
import java.time.ZoneId;

public class DifferenceBetweenDates {
	 LocalDate pdate = LocalDate.of(2012, 01, 01);
     LocalDate now = LocalDate.now();

     public Period diff = Period.between(pdate, now);
     
     public void differenceBetweenDates() {
    	 LocalDate pdate1 = LocalDate.of(2012, 01, 01);
    	 LocalDate pdate2 = LocalDate.of(2015, 03, 29);
    	 Period diff=Period.between(pdate1, pdate2);
    	 System.out.printf("\nDifference between two local dates is %d years, %d months and %d days old\n\n", 
                diff.getYears(),diff.getMonths(), diff.getDays());
     }
     
     public void expiryDate(LocalDate purchaseDate) {
    	 System.out.println("\nWarrantee is 3 months expity date"+purchaseDate.plusMonths(3));
     }
     
     public void zoneCurrentDate(ZoneId zone) {
    	 System.out.println("\n Current date of given "+zone+" is"+LocalDate.now(zone));
     }
}
