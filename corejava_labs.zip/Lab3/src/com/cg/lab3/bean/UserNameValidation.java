package com.cg.lab3.bean;

import java.util.regex.Pattern;

public class UserNameValidation {
	public boolean userNameValid(String userName) {
		String regex="[a-zA-Z0-9]+_job";
		if(userName.matches(regex)&&userName.length()>=8)
			return true;
		else
			return false;
	}
}
