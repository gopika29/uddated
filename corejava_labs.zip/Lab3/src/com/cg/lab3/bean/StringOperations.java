package com.cg.lab3.bean;
public class StringOperations {
	public static String replaceOddChars(String str){
		for (int i=0; i < str.length(); i++){
			if (i % 2 != 0){
//				str = str.substring(0,i-1) + "#" + str.substring(i, str.length());
				str=str.replace(str.charAt(i), '#');
			}
		}
		return str;
	}
	public static String removeDuplicateChars(String str) {
		String str2="";
		char[] temp=str.toCharArray();
		int length=temp.length;
		for (int i = 0; i < length; i++) {
			for (int j = i+1; j<length;j++)
			{
				if(temp[i]==temp[j])
				{
					int test =j;
					for(int k=j+1; k<length; k++)
					{
						temp[test] = temp[k];
						test++;
					}
					length--;
					j--;
				}
			}
		}
		return str2;
	}
	public static String changeOddCharsToUpper(String str){
		char[] arr = str.toCharArray();
		for (int i=0; i < str.length(); i++){
			if(i%2!=0) {
				Character.toUpperCase(arr[i]);
			}
		}
		return arr.toString();
	}
	public static String positiveString(String str) {
		int count=0;
		for (int i = 1; i < str.length(); i++) {
			if(str.charAt(i-1)>str.charAt(i))
				count++;
		}
		if(count==str.length())
			return "positive";
		else return "negative";
		
	}
}
