package com.cg.lab8.client;

import com.cg.lab8.thread.CopyDataThread;
import com.cg.lab8.thread.TimerThread;

public class MainClass {
	public static void main(String args[]) {
		/*Thread th=new CopyDataThread();
		th.start();*/
		Thread th1=new Thread(new TimerThread());
		th1.start();
	}
}
