package com.cg.lab8.thread;

import com.cg.lab8.electronic.ElectronicShop;

public class ElectronicThread implements Runnable{
	private static ElectronicShop electronicShop=new ElectronicShop();
	@Override
	public void run() {
		Thread electronic=Thread.currentThread();
		if(electronic.getName().equals("customer")) {
			try {
				electronicShop.customer();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		else if(electronic.getName().equals("billing")) {
			try {
				electronicShop.billing();
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
		}
		
	}

}
