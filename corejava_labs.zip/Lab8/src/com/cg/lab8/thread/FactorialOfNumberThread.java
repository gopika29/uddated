package com.cg.lab8.thread;

public class FactorialOfNumberThread implements Runnable{
	 public static int turn = 0;
	 public static int number=0;
	 public static Object lock = new Object();
	@Override
	public void run() {
		Thread t=Thread.currentThread();
		int counter=1;
		while(counter<10) {
			synchronized (lock) {
				if(turn==0&&t.getName().equals("number")) {
					number=(int) (Math.random()*10);
					System.out.println("number: "+number);
					turn=1;
					try {
						lock.wait();
					} catch (InterruptedException e) {
						e.printStackTrace();
					}
				}
				else if(turn==1&&t.getName().equals("factorial")) {
					int m=1;
					if(number==0||number==1)
						System.out.println("factorial is:"+1);
					else {
						while(number>0){
							m=m*number;
							number--;
						}
						System.out.println("Factorial is:"+m);
					}
					turn=0;
					lock.notify();
					counter++;
				}
			}
		}
		
	}

}
