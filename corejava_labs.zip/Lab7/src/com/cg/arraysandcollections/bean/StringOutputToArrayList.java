package com.cg.arraysandcollections.bean;

import java.util.ArrayList;
import java.util.List;

public class StringOutputToArrayList {


	public static List<String> stringOperation(StringBuilder s1,StringBuilder s2){
		ArrayList<String> strList=new ArrayList<>();
		String str=s1.toString();
		for (int i = 0; i < str.length(); i++) {
			if(i%2==0)
				str=str.replace(Character.toString(str.charAt(i)), s2.toString());
		}
		strList.add(str);
		for (String string : strList) {
			System.out.println(string);
		}
		/*int count=0;
		for (int i = 0; i <= s1.length() - s2.length(); i++) {    
			int j;
			for (j = 0; j < s2.length(); j++) { 
				if (s1.charAt(i + j) != s1.charAt(j)) 
					break;
			}  
			if (j == s2.length()) {
				count++;
				j = 0;          
			}
			if(count>1)
				break;
		}
		if(count>1) {
			String str=s1.reverse().toString();
			strList.add(str.replaceFirst(s2.toString(), s2.reverse().toString()));
		}*/
		return strList;
	}
}
