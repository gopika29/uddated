package com.cg.arraysandcollections.bean;

import java.util.ArrayList;
import java.util.Collections;

public class ReverseAndSort{
	
	public static  ArrayList<Integer> getSorted(int[] array) {
		ArrayList<Integer> numList=new ArrayList<>();
		for (int i = 0; i < array.length; i++) {
			StringBuilder sb=new StringBuilder(Integer.toString(array[i]));
			array[i]=Integer.parseInt(sb.reverse().toString());
			numList.add(array[i]);
		}
		Collections.sort(numList);
		return numList;
		
	}
}
