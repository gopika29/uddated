package com.cg.lab4.beans;

public class SavingsAccount extends Account{
	private final double MINBAL=500;
	public SavingsAccount() {}
	
	public SavingsAccount(double balance, Person person) {
		super(balance, person);
	}

	@Override
	public void deposit(double depositAmount) {
		setBalance(getBalance()+depositAmount);
	}

	@Override
	public void withdraw(double withdrawAmount) {
		if(getBalance()<=MINBAL||withdrawAmount>=getBalance()) 
			System.out.println("your bal is low");
		else
			setBalance(getBalance()-withdrawAmount);	
	}

	
}
