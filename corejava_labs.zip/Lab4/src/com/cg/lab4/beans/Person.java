package com.cg.lab4.beans;

public class Person {
	private String Name;
	private float age;
	public Person() {}
	
	public Person(String name, float age) {
		super();
		Name = name;
		this.age = age;
	}

	public String getName() {
		return Name;
	}
	public void setName(String name) {
		Name = name;
	}
	public float getAge() {
		return age;
	}
	public void setAge(float age) {
		this.age = age;
	}

	@Override
	public String toString() {
		return "Person [Name=" + Name + ", age=" + age + "]";
	}
	
}
