package com.cg.lab4.beans;

public class CurrentAccount extends Account{
	private final double OVER_DRAFT=200000;
	public CurrentAccount() {}
	
	public CurrentAccount(double balance, Person person) {
		super(balance, person);
	}

	@Override
	public void deposit(double depositAmount) {
		if(getBalance()==OVER_DRAFT)
			System.out.println("you can't deposit now becoz your amount is at over_draft limit");
		else
			setBalance(getBalance()+depositAmount);
	}

	@Override
	public void withdraw(double withdrawAmount) {
		setBalance(getBalance()-withdrawAmount);
	}

	
}
