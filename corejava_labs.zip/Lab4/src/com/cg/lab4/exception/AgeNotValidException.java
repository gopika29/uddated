package com.cg.lab4.exception;

public class AgeNotValidException extends Exception{

	public AgeNotValidException() {
		super();
	}

	public AgeNotValidException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public AgeNotValidException(String message, Throwable cause) {
		super(message, cause);
	}

	public AgeNotValidException(String message) {
		super(message);
	}

	public AgeNotValidException(Throwable cause) {
		super(cause);
	}
	
}
