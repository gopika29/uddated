package com.cg.lab4.util;

public class AccountUtil {
	private static long ACCOUNT_NUMBER=17322800;
	public static long getAccountNumber() {
		return ++ACCOUNT_NUMBER;
		
	}
}
