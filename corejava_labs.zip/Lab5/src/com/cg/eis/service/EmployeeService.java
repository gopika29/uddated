package com.cg.eis.service;

import java.util.List;

import com.cg.eis.bean.Employee;

public interface EmployeeService {
	public String setInsuranceScheme(int salary,String designation);
	public void addEmployee(Employee emp);
	public boolean deleteEmployee(int id);
	public List<Employee> getAllEmployees();
}
