package com.cg.eis.pl;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.Scanner;

import com.cg.eis.bean.Employee;
import com.cg.eis.exception.SalaryNotValidException;
import com.cg.eis.service.EmployeeService;
import com.cg.eis.service.EmployeeServiceImpl;
import com.cg.eis.validation.SalaryValidation;

public class MainClass {

	public static void main(String[] args) {
		Scanner input=new Scanner(System.in);
		int num=0;
		Employee emp = null;
		EmployeeService employeeService=new EmployeeServiceImpl();
		int id,salary = 0;
		String name,designation = null;
		System.out.println("\n1.enter employee details\n2.delete employee\n3.sort&print\n4.exit");
		while(num!=4) {
			switch (num) {
			case 1:
				System.out.println("enter employee id: ");
				id=input.nextInt();
				System.out.println("enter salary: ");
				salary=input.nextInt();
				System.out.println("enter Name: ");
				name=input.next();
				System.out.println("enter designation: ");
				designation=input.next();
				emp=new Employee(id, salary, name, designation);
				
				//lab6.3
				try {
					if(SalaryValidation.checkSalary(emp.getSalary()))
						System.out.println("details are correct");
				} catch (SalaryNotValidException e) {
					e.printStackTrace();
				}
				employeeService.addEmployee(emp);
				emp.setInsuranceScheme(employeeService.setInsuranceScheme(emp.getSalary(), emp.getDesignation()));
				break;
			case 2:
				employeeService.deleteEmployee(input.nextInt());
				break;
			case 3:
				ArrayList<Employee> empList=new ArrayList<>();
				empList=(ArrayList<Employee>) employeeService.getAllEmployees();
				Collections.sort(empList);
				for (Employee employee : empList) 
					System.out.println(employee.toString());
				break;
			default:
				break;
			}
		}
		
		
		
	}

}
