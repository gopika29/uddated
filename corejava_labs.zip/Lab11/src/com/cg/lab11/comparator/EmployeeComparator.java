package com.cg.lab11.comparator;

import java.util.Comparator;

import com.cg.lab11.beans.Employee;

public class EmployeeComparator implements Comparator<Employee>{

	@Override
	public int compare(Employee emp1, Employee emp2) {
		return emp1.getDepartment().getDepartmentId()-emp2.getDepartment().getDepartmentId();
	}

}
