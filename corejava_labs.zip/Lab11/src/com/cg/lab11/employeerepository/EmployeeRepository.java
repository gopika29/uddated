package com.cg.lab11.employeerepository;

import java.time.LocalDate;
import com.cg.lab11.empservice.EmployeeService;

public class EmployeeRepository {
	public static void main(String args[]) {
		EmployeeService employeeService=new EmployeeService();
		employeeService.addEmployee(101, "gopi", "ankani", "g@gmial.com", "8987779", "analyst", LocalDate.of(2018, 01, 01), 
				20000, 111, 10001, "java");
		employeeService.addEmployee(102, "teja", "hemanth", "t@gmial.com", "8987779", "analyst", LocalDate.of(2018, 01, 01), 
				40000, 112, 10001, "crm");
		employeeService.addEmployee(103, "sadhik", "shaik", "s@gmial.com", "8987779", "analyst", LocalDate.of(2018, 01, 01), 
				30000, 111, 10001, "sql");
		employeeService.addEmployee(104, "raja", "ankani", "r@gmial.com", "8987779", "analyst", LocalDate.of(2018, 01, 01), 
				70000, 112, 10001, "java");
		System.out.println(employeeService.sumOfSalaryofAll());
		System.out.println("employee count in each department:"+employeeService.empCountInDepartment());
	}
}
