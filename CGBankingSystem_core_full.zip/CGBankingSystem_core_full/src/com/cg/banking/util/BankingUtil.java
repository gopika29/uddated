package com.cg.banking.util;

import java.util.HashMap;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;

public class BankingUtil {
	public static long CUSTOMER_ID=11087900;
	public static HashMap<Long,Customer> customers=new HashMap<>();
	
	public static long getCUSTOMER_ID() {
		return ++CUSTOMER_ID;
	}
	
	public static long ACCOUNT_NUMBER=423200000;
	public static HashMap<Long,Account> accounts=new HashMap<>();
	
	public static long getACCOUNT_NUMBER() {
		return ++ACCOUNT_NUMBER;
	}

	public static HashMap<Integer, Transaction> transanctions=new HashMap<>();
	public static int TRANSACTION_ID=19300;

	public static int getTRANSACTION_ID() {
		return ++TRANSACTION_ID;
	}
	
}
