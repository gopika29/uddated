package com.cg.banking.beans;



import java.util.Date;

import javax.persistence.Embedded;
import javax.persistence.OneToOne;

public class Customer {
	private Long customerId;
	private String firstName,lastName,emailId,pancard;
	private Date openDate;
	private Long mobileNo,adharNo;

	private Address  address;
	
	
	public Customer() {
	}

	public Customer(String firstName, String lastName, String emailId, String pancard,Long mobileNo,
			Long adharNo, Address address) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.emailId = emailId;
		this.pancard = pancard;
		this.mobileNo = mobileNo;
		this.adharNo = adharNo;
		this.address = address;
	}


	public Long getCustomerId() {
		return customerId;
	}

	public void setCustomerId(Long customerId) {
		this.customerId = customerId;
	}

	public Long getMobileNo() {
		return mobileNo;
	}

	public void setMobileNo(Long mobileNo) {
		this.mobileNo = mobileNo;
	}

	public Long getAdharNo() {
		return adharNo;
	}

	public void setAdharNo(Long adharNo) {
		this.adharNo = adharNo;
	}

	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getEmailId() {
		return emailId;
	}


	public void setEmailId(String emailId) {
		this.emailId = emailId;
	}


	public String getPancard() {
		return pancard;
	}


	public void setPancard(String pancard) {
		this.pancard = pancard;
	}

	

	public Address getAddress() {
		return address;
	}


	public void setAddress(Address address) {
		this.address = address;
	}

	

	public Date getOpenDate() {
		return openDate;
	}

	public void setOpenDate(Date openDate) {
		this.openDate = openDate;
	}
	
	
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", firstName=" + firstName + ", lastName=" + lastName
				+ ", emailId=" + emailId + ", pancard=" + pancard +  ", mobileNo="
				+ mobileNo + ", adharNo=" + adharNo + ", address=" + address + "]";
	}


	


	
	
	
	
}
