package com.cg.banking.daoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.banking.beans.Customer;
import com.cg.banking.util.BankingUtil;

public class CustomerDAOImpl implements CustomerDAO{
	
	@Override
	public Customer save(Customer customer) {
		customer.setCustomerId(BankingUtil.CUSTOMER_ID);
		BankingUtil.customers.put(customer.getCustomerId(), customer);
		return customer;
	}
	@Override
	public boolean update(Customer customer) {
		BankingUtil.customers.put(customer.getCustomerId(), customer);
		return true;
	}
	@Override
	public Customer findone(long customerId) {
		return BankingUtil.customers.get(customerId);
	}
	
	@Override
	public List<Customer> findAll() {
		return new ArrayList<>(BankingUtil.customers.values());
	}

}
