package com.cg.banking.test;

/*import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.stream.Collectors;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.cg.banking.util.BankingUtil;
import com.itextpdf.text.DocumentException;*/

public class BankingTest {
	/*
	 * private static BankingServices bankingServices;
	 * 
	 * @BeforeClass public static void setUpTestEnv() { bankingServices=new
	 * BankingServicesImpl(); }
	 * 
	 * @Before public void setUpTestData() { Account account1=new Account(423200001,
	 * 1234, "savings", "active", 500); Account account2=new Account(423200002,
	 * 3043, "current", "blocked", 500); Account account3=new Account(423200003,
	 * 5678, "savings", "active", 1000); Transaction transaction1=new
	 * Transaction(19301,account1.getAccountBalance(), "deposit",
	 * account1.getAccountNo()); Transaction transaction2=new
	 * Transaction(19302,account2.getAccountBalance(), "deposit",
	 * account2.getAccountNo()); Transaction transaction3=new
	 * Transaction(19303,account3.getAccountBalance(), "deposit",
	 * account3.getAccountNo()); BankingUtil.accounts.put(account1.getAccountNo(),
	 * account1); BankingUtil.accounts.put(account2.getAccountNo(), account2);
	 * BankingUtil.accounts.put(account3.getAccountNo(), account3);
	 * BankingUtil.transanctions.put(transaction1.getTransactionId(), transaction1);
	 * BankingUtil.transanctions.put(transaction2.getTransactionId(), transaction2);
	 * BankingUtil.transanctions.put(transaction3.getTransactionId(), transaction3);
	 * BankingUtil.ACCOUNT_NUMBER=423200003; BankingUtil.TRANSACTION_ID=19303; }
	 * 
	 * @Test public void testForOpenAccountValid() throws InvalidAmountException,
	 * InvalidAccountTypeException, BankingServicesDownException { long
	 * expectedAccountNo=423200004; Account
	 * account=bankingServices.openAccount("savings", 500);
	 * Assert.assertEquals(expectedAccountNo, account.getAccountNo()); }
	 * 
	 * @Test(expected=InvalidAmountException.class) public void
	 * testForOpenAccountInsufficientAmount() throws InvalidAmountException,
	 * InvalidAccountTypeException, BankingServicesDownException {
	 * bankingServices.openAccount("savings", 300); }
	 * 
	 * @Test(expected=InvalidAccountTypeException.class) public void
	 * testForOpenAccountInvalidAccountType() throws InvalidAmountException,
	 * InvalidAccountTypeException, BankingServicesDownException {
	 * bankingServices.openAccount("employee", 500); }
	 * 
	 * @Test(expected=AccountNotFoundException.class) public void
	 * testForDepositAmountForInvalidAccountNo() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException {
	 * bankingServices.depositAmount(123423, 500); }
	 * 
	 * @Test(expected=AccountBlockedException.class) public void
	 * testForDepositAmountForBlockedAccount() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException {
	 * bankingServices.depositAmount(423200002, 500); }
	 * 
	 * @Test public void testForDepositWithAllValid() throws
	 * AccountNotFoundException, BankingServicesDownException,
	 * AccountBlockedException { float expectedAmount=1000; float
	 * actualAmount=bankingServices.depositAmount(423200001, 500);
	 * Assert.assertEquals(expectedAmount, actualAmount, 0); }
	 * 
	 * @Test(expected=AccountBlockedException.class) public void
	 * testForWithdrawAmountForBlockedAccount() throws AccountNotFoundException,
	 * BankingServicesDownException, AccountBlockedException,
	 * InsufficientAmountException, InvalidPinNumberException {
	 * bankingServices.withdrawAmount(423200002, 500, 3043); }
	 * 
	 * @Test(expected=InvalidPinNumberException.class) public void
	 * testForWithdrawAmountWithInvalidPin() throws InsufficientAmountException,
	 * AccountNotFoundException, InvalidPinNumberException,
	 * BankingServicesDownException, AccountBlockedException {
	 * bankingServices.withdrawAmount(423200001, 500, 3433); }
	 * 
	 * @Test(expected=InsufficientAmountException.class) public void
	 * testForWithdrawAmountForInsufficientAmount() throws
	 * InsufficientAmountException, AccountNotFoundException,
	 * InvalidPinNumberException, BankingServicesDownException,
	 * AccountBlockedException { bankingServices.withdrawAmount(423200001, 500,
	 * 1234); }
	 * 
	 * @Test public void testForWithdrawAmountForAllValid() throws
	 * InsufficientAmountException, AccountNotFoundException,
	 * InvalidPinNumberException, BankingServicesDownException,
	 * AccountBlockedException { float expectedAmount=300; float
	 * actualAmount=bankingServices.withdrawAmount(423200001, 200, 1234);
	 * Assert.assertEquals(expectedAmount, actualAmount,0); }
	 * 
	 * @Test(expected=AccountBlockedException.class) public void
	 * testForFundTransferFromBlockedAccount() throws InsufficientAmountException,
	 * AccountNotFoundException, InvalidPinNumberException,
	 * BankingServicesDownException, AccountBlockedException {
	 * bankingServices.fundTransfer(423200001, 423200002, 100, 3043); }
	 * 
	 * @Test(expected=AccountBlockedException.class) public void
	 * testForFundTransferToBlockedAccount() throws InsufficientAmountException,
	 * AccountNotFoundException, InvalidPinNumberException,
	 * BankingServicesDownException, AccountBlockedException {
	 * bankingServices.fundTransfer(423200002, 423200001, 100, 1234); }
	 * 
	 * @Test(expected=InvalidPinNumberException.class) public void
	 * testForFundTransferWithInvalidPinNumber() throws InsufficientAmountException,
	 * AccountNotFoundException, InvalidPinNumberException,
	 * BankingServicesDownException, AccountBlockedException {
	 * bankingServices.fundTransfer(423200001, 423200003, 100, 2312); }
	 * 
	 * @Test(expected=InsufficientAmountException.class) public void
	 * testForFundTransferWithInsufficientAmount() throws
	 * InsufficientAmountException, AccountNotFoundException,
	 * InvalidPinNumberException, BankingServicesDownException,
	 * AccountBlockedException { bankingServices.fundTransfer(423200003, 423200001,
	 * 500, 1234); }
	 * 
	 * @Test public void testForFundTransferForAllValid() throws
	 * InsufficientAmountException, AccountNotFoundException,
	 * InvalidPinNumberException, BankingServicesDownException,
	 * AccountBlockedException { boolean expectedValue=true; boolean
	 * actualValue=bankingServices.fundTransfer(423200001, 423200003, 100, 5678);
	 * Assert.assertEquals(expectedValue, actualValue); }
	 * 
	 * @Test(expected=AccountNotFoundException.class) public void
	 * testForGetAccountDetailsForInvalidAccountNo() throws
	 * AccountNotFoundException, BankingServicesDownException {
	 * bankingServices.getAccountDetails(27493475); }
	 * 
	 * @Test public void testForGetAccountDetailsForValidAccountNo() throws
	 * AccountNotFoundException, BankingServicesDownException { Account
	 * expectedAccount=new Account(423200003, 5678, "savings", "active", 1000);
	 * Account actualAccount=bankingServices.getAccountDetails(423200003);
	 * Assert.assertEquals(expectedAccount, actualAccount); }
	 * 
	 * @Test public void testForGetAllAccounts() { ArrayList<Account>
	 * expectedAccounts=new ArrayList<>(BankingUtil.accounts.values());
	 * ArrayList<Account> actualAccounts=(ArrayList<Account>)
	 * bankingServices.getAllAccountDetails(); Assert.assertEquals(expectedAccounts,
	 * actualAccounts); }
	 * 
	 * @Test(expected=AccountBlockedException.class) public void
	 * testForGetAccountStatusForBlockedAccount() throws
	 * BankingServicesDownException, AccountNotFoundException,
	 * AccountBlockedException { bankingServices.accountStatus(423200002); }
	 * 
	 * @Test(expected=AccountNotFoundException.class) public void
	 * testForGetAccountStatusForInvalidAccountNumber() throws
	 * BankingServicesDownException, AccountNotFoundException,
	 * AccountBlockedException { bankingServices.accountStatus(4556456); }
	 * 
	 * @Test public void testForGetAccountStatusForValidAccountNumber() throws
	 * BankingServicesDownException, AccountNotFoundException,
	 * AccountBlockedException { bankingServices.accountStatus(423200003); }
	 * 
	 * @Test(expected=AccountNotFoundException.class) public void
	 * testForGetAllTransactionsForInvalidAccountNumber() throws
	 * BankingServicesDownException, AccountNotFoundException {
	 * bankingServices.getAccountAllTransaction(4556645); }
	 * 
	 * @Test public void testForGetAllTransactionsForValidAccountNumber() throws
	 * BankingServicesDownException, AccountNotFoundException {
	 * ArrayList<Transaction> transactions=new
	 * ArrayList<>(BankingUtil.transanctions.values()); ArrayList<Transaction>
	 * expectedTransactions=(ArrayList<Transaction>)
	 * transactions.stream().filter(t->t.getAccountNo()==423200003).collect(
	 * Collectors.toList()); ArrayList<Transaction>
	 * actualTransactions=(ArrayList<Transaction>)
	 * bankingServices.getAccountAllTransaction(423200003);
	 * Assert.assertEquals(expectedTransactions, actualTransactions); }
	 * 
	 * @Test(expected=AccountNotFoundException.class) public void
	 * testForPdfGenerationForInvalidAccountNumber() throws FileNotFoundException,
	 * DocumentException, BankingServicesDownException, AccountNotFoundException {
	 * bankingServices.pdfGenerator(435677656); }
	 * 
	 * @Test public void testForPdfGenerationForValidAccountNumber() throws
	 * FileNotFoundException, DocumentException, BankingServicesDownException,
	 * AccountNotFoundException { bankingServices.pdfGenerator(423200003); }
	 * 
	 * @After public void tearDownTestData() { BankingUtil.ACCOUNT_NUMBER=423200000;
	 * BankingUtil.TRANSACTION_ID=19300; BankingUtil.accounts.clear();
	 * BankingUtil.transanctions.clear(); }
	 * 
	 * @AfterClass public static void tearDownTestEnv() { bankingServices=null; }
	 */
}
