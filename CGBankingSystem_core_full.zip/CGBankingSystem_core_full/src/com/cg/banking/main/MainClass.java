package com.cg.banking.main;

import java.io.FileNotFoundException;
import java.util.Scanner;

import com.cg.banking.beans.Account;
import com.cg.banking.beans.Address;
import com.cg.banking.beans.Customer;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingServices;
import com.cg.banking.services.BankingServicesImpl;
import com.itextpdf.text.DocumentException;

public class MainClass {
	public static void main(String[] args) {
		@SuppressWarnings("resource")
		Scanner ip=new Scanner(System.in);
		BankingServices bankingServices=new BankingServicesImpl();
		int num=0,pinCode;
		String firstName,lastName,emailId,pancard,accountType,city,state,country;;
		long mobileNo,adharNo,accountNo1,accountNo2;
		float accountBalance;
		try {
			while(num!=7) {
				System.out.println("1.open account\n2.deposit\n3.withdraw\n4.transfer\n5.getAccountDetails\n6.getAllAccounts"
						+ "\n7.getAllAccountTransaction\n8.exit\nenter number: ");
				num=ip.nextInt();
				switch (num) {
				case 1:
					System.out.println("enter firstname:");
					firstName=ip.next();
					System.out.println("enter lastname:");
					lastName=ip.next();
					System.out.println("eter email id: ");
					emailId=ip.next();
					System.out.println("enter pancard:");
					pancard=ip.next();
					System.out.println("enter mobileno:");
					mobileNo=ip.nextLong();
					System.out.println("enter adharNo:");
					adharNo=ip.nextLong();
					System.out.println("enter city");
					city=ip.next();
					System.out.println("enter state:");
					state=ip.next();
					System.out.println("enter country:");
					country=ip.next();
					System.out.println("enter pincode:");
					pinCode=ip.nextInt();
					System.out.println("enter accountType:");
					accountType=ip.next();
					System.out.println("enter initial balance:");
					accountBalance=ip.nextFloat();
					Account account=bankingServices.openAccount(new Customer(firstName, lastName, emailId, pancard, mobileNo, adharNo,
							new Address(city, state, country, pinCode)), new Account(accountType, accountBalance));
					System.out.println("account number:"+account.getAccountNo()+"pin number:"+account.getPinNumber());
					break;
				case 2:
					System.out.println("enter account No:");
					accountNo1=ip.nextLong();
					System.out.println("enter money to deposit: ");
					System.out.println(bankingServices.depositAmount(accountNo1, ip.nextInt()));
					break;
				case 3:
					System.out.println("enter account No:");
					accountNo1=ip.nextLong();
					System.out.println("enter money to withdraw: ");
					accountBalance=ip.nextFloat();
					System.out.println("enter pinNumber: ");
					System.out.println(bankingServices.withdrawAmount(accountNo1, accountBalance, ip.nextInt()));
					break;
				case 4:
					System.out.println("enter account No From:");
					accountNo1=ip.nextLong();
					System.out.println("enter money to transfer: ");
					accountBalance=ip.nextFloat();
					System.out.println("enter account No To:");
					accountNo2=ip.nextLong();
					System.out.println("enter pinNumber: ");
					System.out.println(bankingServices.fundTransfer(accountNo2, accountNo1, accountBalance, 
							ip.nextInt()));
					break;
				case 5:
					System.out.println("enter account No:");
					System.out.println(bankingServices.getAccountDetails(ip.nextLong()));
					break;
				case 6:
					System.out.println(bankingServices.getAllAccountDetails());
					break;
				case 7:
					System.out.println("enter account No:");
					accountNo1=ip.nextLong();
					System.out.println(bankingServices.getAccountAllTransaction(accountNo1));
					bankingServices.pdfGenerator(accountNo1);
					break;
				default:
					System.out.println("you entered default case");
					break;
				}
			}
			
		} catch (InvalidAmountException | InvalidAccountTypeException | BankingServicesDownException | AccountNotFoundException | AccountBlockedException | InsufficientAmountException | InvalidPinNumberException | FileNotFoundException | DocumentException e) {
			e.printStackTrace();
		}
	}
}
