package com.cg.banking.daoservices;

import java.util.List;

import com.cg.banking.beans.Customer;
public interface CustomerDAO {
	Customer save(Customer customer);
	boolean update(Customer customer);
	Customer findone(long customerId);
	List<Customer> findAll();
}
