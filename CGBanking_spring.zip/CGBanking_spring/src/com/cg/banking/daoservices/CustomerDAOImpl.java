package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Customer;
@Repository("customerDAO")
@Transactional
public class CustomerDAOImpl implements CustomerDAO{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Customer save(Customer customer) {
		entityManager.persist(customer);
		entityManager.flush();
		return customer;
	}
	@Override
	public boolean update(Customer customer) {
		entityManager.merge(customer);
		entityManager.flush();
		return false;
	}
	@Override
	public Customer findone(long customerId) {
		return entityManager.find(Customer.class, customerId);
	}
	@SuppressWarnings("unchecked")
	@Override
	public List<Customer> findAll() {
		return entityManager.createQuery("from Customer c").getResultList();
	}

}
