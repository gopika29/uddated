package com.cg.banking.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.banking.beans.Transaction;
@Repository("transactionDAO")
@Transactional
public class TransactionDAOImpl implements TransactionDAO{
	@PersistenceContext
	EntityManager entityManager;
	@Override
	public Transaction save(Transaction transaction) {
	
		entityManager.persist(transaction);
		entityManager.flush();
		return transaction;
	}

	@Override
	public boolean update(Transaction transaction) {
		
		entityManager.merge(transaction);
		entityManager.flush();
		return true;
	}

	@Override
	public Transaction findOne(int transactionId) {
		return entityManager.find(Transaction.class, transactionId);
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Transaction> findAll(long accountNo) {
		return 	entityManager.createQuery("select t from Transaction t where ACCOUNTNO="+accountNo).getResultList();
	}

}
