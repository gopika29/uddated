package com.cg.hotelbooking.pagefactorystepdefinition;

import static org.testng.Assert.assertEquals;
import static org.testng.Assert.assertTrue;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.junit.Assert;
import org.openqa.selenium.Alert;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import com.cg.hotelbooking.pagefactory.HotelBookingPageFactory;
import com.cg.hotelbooking.pagefactory.HotelLoginPageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class HotelPageFactoryStepDefinition {
	private WebDriver driver;
	private HotelBookingPageFactory hotelBookingPageFactory;
	private HotelLoginPageFactory hotelLoginPageFactory;
	String title;
	@Before
	public void openBrowser() {
		String driverPath = "D:\\gankani_GopaKumari_Ankani\\BDD\\Selenium\\chromedriver_win32\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
	}
	//--------Login Page------------------------------------
	@Given("^user is currently on login page$")
	public void user_is_currently_on_login_page() throws Throwable {
	    hotelLoginPageFactory= new HotelLoginPageFactory(driver);
	    driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
	    driver.get("file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/login.html");
	}

	@When("^user is given valid credentials$")
	public void user_is_given_valid_credentials() throws Throwable {
	    hotelLoginPageFactory.setUserName("capgemini");Thread.sleep(1000);
	    hotelLoginPageFactory.setPassword("capg1234");Thread.sleep(1000);
	    hotelLoginPageFactory.setLoginButton();Thread.sleep(1000);
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Then("^user is navigate to hotel booking page$")
	public void user_is_navigate_to_hotel_booking_page() throws Throwable {
		driver.navigate().to("file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/hotelbooking.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}
	
	@When("^user name is empty$")
	public void user_name_is_empty() throws Throwable {
	   hotelLoginPageFactory.setUserName("");Thread.sleep(1000);
	   hotelLoginPageFactory.setLoginButton();Thread.sleep(1000);
	   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@Then("^display error msg$")
	public void display_error_msg() throws Throwable {
	   assertTrue(driver.getPageSource().contains("* Please enter"));
	}
	
	@When("^password is empty$")
	public void password_is_empty() throws Throwable {
	  hotelLoginPageFactory.setUserName("capgemini");Thread.sleep(1000);
	  hotelLoginPageFactory.setPassword("");Thread.sleep(1000);
	  hotelLoginPageFactory.setLoginButton();Thread.sleep(1000);
	   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

	@When("^username or password are wrong$")
	public void username_or_password_are_wrong() throws Throwable {
		hotelLoginPageFactory.setUserName("hsfdhhkj");Thread.sleep(1000);
		  hotelLoginPageFactory.setPassword("capge0r7");Thread.sleep(1000);
		  hotelLoginPageFactory.setLoginButton();Thread.sleep(1000);
		   driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}

//------------------------Hotel Booking page-------------------------------------

	@Given("^user is on hotel booking page$")
	public void user_is_on_hotel_booking_page() throws Throwable {
		hotelBookingPageFactory=new HotelBookingPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/hotelbooking.html");
		title=driver.getTitle();
	}

	@Then("^check the title of the page$")
	public void check_the_title_of_the_page() throws Throwable {
		assertEquals("Hotel Booking", title);
	}
	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Telangana");
		hotelBookingPageFactory.setPfPersons(2);
		hotelBookingPageFactory.setPfCardHolder("Gopika Ankani");
		hotelBookingPageFactory.setPfDebitCardNumber("946643476764");
		hotelBookingPageFactory.setPfCvv("454");
		hotelBookingPageFactory.setPfExpiryMonth("08");
		hotelBookingPageFactory.setPfExpiryYear("2023");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		hotelBookingPageFactory.setPfButton();
	}

	@Then("^navigate to welcome page$")
	public void navigate_to_welcome_page() throws Throwable {
		driver.navigate().to("file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/success.html");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
	}
	@When("^user leaves first Name blank$")
	public void user_leaves_first_Name_blank() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("");
		Thread.sleep(1000);

	}

	@When("^clicks the button$")
	public void clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfButton();
	}

	@Then("^display alert msg$")
	public void display_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("******" + alertMessage);
	}
	@When("^user leaves last Name blank and clicks the button$")
	public void user_leaves_last_Name_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("Gopika");
		hotelBookingPageFactory.setPfLastName("");
		hotelBookingPageFactory.setPfButton();
	}
	@When("^user gives invalid email format$")
	public void user_gives_invalid_email_format() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("Gopika");
		hotelBookingPageFactory.setPfLastName("Ankani");
		hotelBookingPageFactory.setPfEmail("hfgoh.com");
		hotelBookingPageFactory.setPfButton();
	}
	@When("^user leaves MobileNo blank and clicks the button$")
	public void user_leaves_MobileNo_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("");
		hotelBookingPageFactory.setPfButton();
	}
	@When("^user enters incorrect mobileNo format and clicks the button$")
	public void user_enters_incorrect_mobileNo_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		List<String> objList = arg1.asList(String.class);
		//objhbpg.setPfmobile(objList);	Thread.sleep(1000);
		hotelBookingPageFactory.setPfButton();

		for(int i=0; i<objList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", objList.get(i))) 
				System.out.println("***** Matched" + objList.get(i) + "*****");
			else 
				System.out.println("***** NOT Matched" + objList.get(i) + "*****");
		}
	}
	@When("^user doesnot select city$")
	public void user_doesnot_select_city() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Select City");
		hotelBookingPageFactory.setPfButton();
	}
	@When("^user doesnot select state$")
	public void user_doesnot_select_state() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Select State");
		hotelBookingPageFactory.setPfButton();
	}
	@When("^user enters (\\d+)$")
	public void user_enters(int arg1) throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Telangana");
		hotelBookingPageFactory.setPfPersons(arg1);
	}

	@Then("^allocate rooms such that (\\d+) room for minimum (\\d+) guests$")
	public void allocate_rooms_such_that_room_for_minimum_guests(int arg1, int arg2) throws Throwable {
		if(arg2 <=3) {
	    	System.out.println("***** 1 room");
	    	assertEquals(1, arg1);
	    }
	    else if(arg2 <=6){
	    	System.out.println("***** 2 rooms");
	    	assertEquals(2, arg1); 	
	    }	 
	    else if(arg2 <=9){
	    	System.out.println("***** 3 rooms");
	    	assertEquals(3, arg1); 	
	    }
	}
	@When("^user leaves CardHolderName blank and clicks the button$")
	public void user_leaves_CardHolderName_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Telangana");
		hotelBookingPageFactory.setPfPersons(2);
		hotelBookingPageFactory.setPfCardHolder("");
		hotelBookingPageFactory.setPfButton();
	}
	@When("^user leaves DebitCardNo blank and clicks the button$")
	public void user_leaves_DebitCardNo_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Telangana");
		hotelBookingPageFactory.setPfPersons(2);
		hotelBookingPageFactory.setPfCardHolder("Gopika Ankani");
		hotelBookingPageFactory.setPfDebitCardNumber("");
		hotelBookingPageFactory.setPfButton();
	}

	@When("^user leaves expirationMonth blank and clicks the button$")
	public void user_leaves_expirationMonth_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Telangana");
		hotelBookingPageFactory.setPfPersons(2);
		hotelBookingPageFactory.setPfCardHolder("Gopika Ankani");
		hotelBookingPageFactory.setPfDebitCardNumber("946643476764");
		hotelBookingPageFactory.setPfCvv("454");
		hotelBookingPageFactory.setPfExpiryMonth("");
		hotelBookingPageFactory.setPfButton();
	}

	@When("^user leaves expirationYr blank and clicks the button$")
	public void user_leaves_expirationYr_blank_and_clicks_the_button() throws Throwable {
		hotelBookingPageFactory.setPfFirstName("gopika");
		hotelBookingPageFactory.setPfLastName("ankani");
		hotelBookingPageFactory.setPfEmail("gopika@gmail.com");
		hotelBookingPageFactory.setPfMobile("8986747455");
		hotelBookingPageFactory.setPfAddress("Andhra pradesh");
		hotelBookingPageFactory.setPfCity("Hyderabad");
		hotelBookingPageFactory.setPfState("Telangana");
		hotelBookingPageFactory.setPfPersons(2);
		hotelBookingPageFactory.setPfCardHolder("Gopika Ankani");
		hotelBookingPageFactory.setPfDebitCardNumber("946643476764");
		hotelBookingPageFactory.setPfCvv("454");
		hotelBookingPageFactory.setPfExpiryMonth("08");
		hotelBookingPageFactory.setPfExpiryYear("");
		driver.manage().timeouts().implicitlyWait(70, TimeUnit.SECONDS);
		hotelBookingPageFactory.setPfButton();
	}
	@After
	public void closeBrowser() {
		driver.close();
	}
}
