package com.cg.hotelbooking.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HotelLoginPageFactory {
	WebDriver driver;
	
	@FindBy(name="userName")
	@CacheLookup
	WebElement userName;
	
	@FindBy(xpath=".//*[@id='mainCnt']/div/div[1]/form/table/tbody/tr[3]/td[2]/input")
	@CacheLookup
	WebElement password;
	
	@FindBy(className="btn")
	@CacheLookup
	WebElement loginButton;

	public HotelLoginPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}

	public WebElement getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName.sendKeys(userName);
	}

	public WebElement getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password.sendKeys(password);
	}

	public WebElement getLoginButton() {
		return loginButton;
	}

	public void setLoginButton() {
		this.loginButton.click();
	}
	
	
	
}
