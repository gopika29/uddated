package com.cg.hotelbooking.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class HotelBookingPageFactory {
	WebDriver driver;
	//step1: identify elements
	@FindBy(name="txtFN")
	@CacheLookup
	WebElement pfFirstName;
	
	//using how class
	@FindBy(how=How.ID,using="btnPayment")
	@CacheLookup
	WebElement pfButton;
	
	@FindBy(xpath=".//*[@id='txtLastName']")
	@CacheLookup
	WebElement pfLastName;
	
	@FindBy(how=How.NAME,using="Email")
	@CacheLookup
	WebElement pfEmail;
	
	@FindBy(css="input[ pattern='[789][0-9]{9}']")
	@CacheLookup
	WebElement pfMobile;
	
	@FindBy(tagName="textarea")
	@CacheLookup
	WebElement pfAddress;
	
	@FindBy(how=How.NAME,using="city")
	@CacheLookup
	WebElement pfCity;
	
	@FindBy(how=How.NAME,using="state")
	@CacheLookup
	WebElement pfState;
	
	@FindBy(how=How.NAME,using="persons")
	@CacheLookup
	int pfPersons;
	
	@FindBy(xpath=".//*[@id='rooms']")
	@CacheLookup
	WebElement pfRooms;
	
	@FindBy(how=How.ID,using="txtCardholderName")
	@CacheLookup
	WebElement pfCardHolder;
	
	@FindBy(how=How.ID,using="txtDebit")
	@CacheLookup
	WebElement pfDebitCardNumber;
	
	@FindBy(how=How.NAME,using="cvv")
	@CacheLookup
	WebElement pfCvv;
	
	@FindBy(name="month")
	@CacheLookup
	WebElement pfExpiryMonth;
	
	@FindBy(name="year")
	@CacheLookup
	WebElement pfExpiryYear;
	
	//step 2: setters................................
	public void setPfFirstName(String sfName) {
		pfFirstName.sendKeys(sfName);
	}
	public void setPfButton() {
		pfButton.click();
	}

	public void setPfLastName(String pfLastName) {
		this.pfLastName.sendKeys(pfLastName);
	}

	public void setPfEmail(String pfEmail) {
		this.pfEmail.sendKeys(pfEmail);
	}

	public void setPfMobile(String pfMobile) {
		this.pfMobile.sendKeys(pfMobile);
	}

	public void setPfAddress(String pfAddress) {
		this.pfAddress.sendKeys(pfAddress);
	}

	public void setPfCity(String pfCity) {
		Select drpCity=new Select(this.pfCity);
		drpCity.selectByVisibleText(pfCity);
	}

	public void setPfState(String pfState) {
		Select drpState=new Select(this.pfState);
		drpState.selectByVisibleText(pfState);
	}

	public void setPfPersons(int pfPersons) {
		this.pfPersons = pfPersons;
	}

	
	public void setPfCardHolder(String pfCardHolder) {
		this.pfCardHolder.sendKeys(pfCardHolder);
	}

	public void setPfDebitCardNumber(String pfDebitCardNumber) {
		this.pfDebitCardNumber.sendKeys(pfDebitCardNumber);
	}

	public void setPfCvv(String pfCvv) {
		this.pfCvv.sendKeys(pfCvv);
	}

	public void setPfExpiryMonth(String pfExpiryMonth) {
		this.pfExpiryMonth.sendKeys(pfExpiryMonth);;
	}

	public void setPfExpiryYear(String pfExpiryYear) {
		this.pfExpiryYear.sendKeys(pfExpiryYear);
	}
	//getters
	public WebDriver getDriver() {
		return driver;
	}
	public WebElement getPfFirstName() {
		return pfFirstName;
	}
	public WebElement getPfButton() {
		return pfButton;
	}
	public WebElement getPfLastName() {
		return pfLastName;
	}
	public WebElement getPfEmail() {
		return pfEmail;
	}
	public WebElement getPfMobile() {
		return pfMobile;
	}
	public WebElement getPfAddress() {
		return pfAddress;
	}
	public WebElement getPfCity() {
		return pfCity;
	}
	public WebElement getPfState() {
		return pfState;
	}
	public int getPfPersons() {
		return pfPersons;
	}
	public WebElement getPfRooms() {
		return pfRooms;
	}
	public WebElement getPfCardHolder() {
		return pfCardHolder;
	}
	public WebElement getPfDebitCardNumber() {
		return pfDebitCardNumber;
	}
	public WebElement getPfCvv() {
		return pfCvv;
	}
	public WebElement getPfExpiryMonth() {
		return pfExpiryMonth;
	}
	public WebElement getPfExpiryYear() {
		return pfExpiryYear;
	}
	public HotelBookingPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	
	
}
