package com.cg.hotelbooking.alerts;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class HotelLoginWithSelenium {
	static WebDriver driver=null;
	static String alertMessage=null;
	public static void main(String[] args) {
		String driverPath = "D:\\gankani_GopaKumari_Ankani\\BDD\\Selenium\\chromedriver_win32\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		try {
			driver.get("file:///D:/gankani_GopaKumari_Ankani/BDD/Selenium/login.html");
			driver.findElement(By.name("userName")).sendKeys("");
			Thread.sleep(1000);

			driver.findElement(By.className("btn")).click();Thread.sleep(1000);
			System.out.println(driver.findElement(By.xpath(".//*[@id='userErrMsg']")).getText());Thread.sleep(1000);
			driver.findElement(By.name("userName")).sendKeys("gopika");Thread.sleep(1000);

			driver.findElement(By.name("userPwd")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.className("btn")).click();Thread.sleep(1000);
			System.out.println(driver.findElement(By.xpath(".//*[@id='pwdErrMsg']")).getText());Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("gopika");Thread.sleep(1000);

			driver.findElement(By.className("btn")).click();Thread.sleep(1000);
			callAlert();

			driver.findElement(By.name("userName")).clear();
			driver.findElement(By.name("userPwd")).clear();

			driver.findElement(By.name("userName")).sendKeys("capgemini");Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("gopika");Thread.sleep(1000);
			driver.findElement(By.className("btn")).click();Thread.sleep(1000);
			callAlert();

			driver.findElement(By.name("userName")).clear();
			driver.findElement(By.name("userPwd")).clear();

			driver.findElement(By.name("userName")).sendKeys("gopika");Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("capg1234");Thread.sleep(1000);
			driver.findElement(By.className("btn")).click();Thread.sleep(1000);
			callAlert();

			driver.findElement(By.name("userName")).clear();
			driver.findElement(By.name("userPwd")).clear();

			driver.findElement(By.name("userName")).sendKeys("capgemini");Thread.sleep(1000);
			driver.findElement(By.name("userPwd")).sendKeys("capg1234");Thread.sleep(1000);
			driver.findElement(By.className("btn")).click();Thread.sleep(1000);
			System.out.println("login success");
		} catch (InterruptedException e) {
			System.out.println("some exception occurs:"+e);
		}


	}
	public static void callAlert(){
		alertMessage= driver.switchTo().alert().getText();
		System.out.println(alertMessage);		
		driver.switchTo().alert().accept();

	}
}
