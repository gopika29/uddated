package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public interface PayrollServices {
	int acceptAssociateDetails( String firstName, String lastName,String emailId,
			String department, String designation, String pancard, int yearlyInvestmentUnder80C,float basicSalary, float epf, float companypf,
			int accountNumber, String bankName, String ifscCode);
	
	float calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException;
	Associate getAsscoiateDetails(int associateId)throws AssociateDetailsNotFoundException;
	
	List<Associate> getAllAssociateDetails();

}
