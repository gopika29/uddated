package com.cg.payroll.client;

import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;
import java.util.Scanner;

import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;
import com.cg.payroll.util.DBUtil;

public class MainClass {
	public static void main(String[] args){
		

		/*Associate[]  associates=new Associate[5];
		associates[0]=new Associate(111,134939,"gopi","ankani","JEE","Trainee","HDHJJ89848","gopi@gmail.com",new Salary(30000,1000,1000),new BankDetails(23808327,"HDFC","HDFC384787"));
		associates[1]=new Associate(101,132339,"teja","hemanth","JEE","Trainee","DGHDGH3534","teja@gmail.com",new Salary(40000,1000,1000),new BankDetails(23848727,"HDFC","HDFC384787"));
		associates[2]=new Associate(134,123439,"sadhik","shaik","JEE","Trainee","HDHJJ3432","sadhik@gmail.com",new Salary(30000,1000,1000),new BankDetails(450748327,"CITI","CITI384073"));
		associates[3]=new Associate(149,123439,"madhu","m","JEE","Trainee","HSDJ3432","madhu@gmail.com",new Salary(10000,1000,1000),new BankDetails(450454534,"ICICI","ICICI384768"));
		associates[4]=new Associate(143,123439,"preeti","sr","JEE","Trainee","SCDJ3432","preeti@gmail.com",new Salary(20000,1000,1000),new BankDetails(450766565,"CITI","CITI384073"));
		for(Associate associate:associates) {
			if(associate.getSalary().getBasicSalary()>20000 && associate.getBankDetails().getBankName()=="HDFC") 
				System.out.println(associate.getAssociateID()+" "+associate.getFirstName()+" "+associate.getLastName());
		}*/
		try {
			PayrollServices payrollServices=new PayrollServicesImpl();
			Scanner input=new Scanner(System.in);
			int num=0;
			while(num!=5) {
				System.out.println("1.inserting\n2.calculate netSalary\n3.getone\n4.getAll\n5.exit\n");
				 num=input.nextInt();
				switch (num) {
				case 1:
					int associateId=payrollServices.acceptAssociateDetails("gopi", "ankani", "gopi@gmail.com", "trainee", "Analyst", "DDHH344", 193934, 200000, 8000, 3000, 2384085, "HDFC", "hdfc485433");
					associateId=payrollServices.acceptAssociateDetails("teja", "hemanth", "teja@gmail.com", "trainee", "Anaylyst", "DHF3834", 200000, 30000, 7000, 2000, 2034024, "ICICI", "icici4804");
					associateId=payrollServices.acceptAssociateDetails("sadhik", "shaik", "sadhik@gmail.com", "trainee", "Analyst", "SDHFH343", 190000, 20000, 2000, 3000, 10034234, "CITI", "citi82802");
					associateId=payrollServices.acceptAssociateDetails("raja", "ankani", "raja@gmail.com", "trainee", "Analyst", "SDHFH343", 200000, 60000, 3000, 2000, 10056456, "CITI", "citi82802");
					System.out.println("Associate Id :-"+associateId);
					break;
				case 2:
					System.out.println(payrollServices.calculateNetSalary(101));
					break;
				case 3:
					System.out.println(payrollServices.getAsscoiateDetails(101));
					break;
				case 4:
					System.out.println(payrollServices.getAllAssociateDetails());
					break;
				default:
					System.out.println("you entered default case");
					break;
				}
			}

		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		} 
	

	}
}
