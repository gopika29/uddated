package com.cg.electricitybilldaoservices;

import java.util.ArrayList;
import java.util.List;

import com.cg.electricitybillgeneration.beans.Customer;
import com.cg.electricitybillgeneration.util.ElectricityUtil;

public class CustomerDaoImpl implements CustomerDao{

	@Override
	public Customer save(Customer customer) {
		customer.setCustomerNo(ElectricityUtil.getCUSTOMER_NO_COUNTER());
		ElectricityUtil.customers.put(customer.getCustomerNo(), customer);
		return customer;
	}

	@Override
	public boolean update(Customer customer) {
		ElectricityUtil.customers.put(customer.getCustomerNo(), customer);
		return true;
	}

	@Override
	public Customer findOne(int customerNo) {
		return ElectricityUtil.customers.get(customerNo);
	}

	@Override
	public List<Customer> findAll() {
		return new ArrayList<>(ElectricityUtil.customers.values());
	}

}
