package com.cg.electricitybillgeneration.client;

import java.util.Scanner;

import com.cg.electricitybillgeneration.exception.CustomerDetailsNotFoundException;
import com.cg.electricitybillservices.ElectricityBillServices;
import com.cg.electricitybillservices.ElectricityBillServicesImpl;

public class Mainclass {

	public static void main(String[] args) {
		try {
			ElectricityBillServices electricityBillServices=new ElectricityBillServicesImpl();
			int customerNo=electricityBillServices.acceptCustomerDetails(4534565, "sadhik", "shaik", "GDT63286","shaik@gmail.com", 840834, 1200, 1, "three",123423, 
					"10-09-2018", "48shfhh", "sep", 254543, 2, "maharashtra", "pune", "234-a");
			System.out.println("Associate Id :-"+customerNo);
			Scanner input=new Scanner(System.in);
			int num=0;
			boolean value=true;
			while(value) {
				System.out.println("enter number which method you want to implement:");
				 num=input.nextInt();
				switch (num) {
				case 1:
					System.out.println(electricityBillServices.generateBill(customerNo));
					break;
				case 2:
					System.out.println(electricityBillServices.getCustomerDetails(customerNo));
					break;
				case 3:
					System.out.println(electricityBillServices.getAllCustomerDetails());
					break;
				default:
					System.out.println("you entered default case");
					value=false;
					break;
				}
			}

		} catch (CustomerDetailsNotFoundException e) {
			e.printStackTrace();
		}


	}

}
