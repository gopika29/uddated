package com.cg.electricitybillgeneration.beans;

public class Customer {
	private int customerNo,mobileNo;
	private String firstName,lastName,panCard,email;
	private Meter meter;
	private Address address;
	public Customer() {}
	public Customer(int customerNo, int mobileNo, String firstName, String lastName, String panCard, String email) {
		super();
		this.customerNo = customerNo;
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.panCard = panCard;
		this.email = email;
	}

	public Customer(int customerNo, int mobileNo, String firstName, String lastName, String panCard, String email,
			Meter meter, Address address) {
		super();
		this.customerNo = customerNo;
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.panCard = panCard;
		this.email = email;
		this.meter = meter;
		this.address = address;
	}
	public Customer(int mobileNo, String firstName, String lastName, String panCard, String email,
			Meter meter, Address address) {
		super();
		this.mobileNo = mobileNo;
		this.firstName = firstName;
		this.lastName = lastName;
		this.panCard = panCard;
		this.email = email;
		this.meter = meter;
		this.address = address;
	}
	public int getCustomerNo() {
		return customerNo;
	}
	public void setCustomerNo(int customerNo) {
		this.customerNo = customerNo;
	}
	public int getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(int mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getPanCard() {
		return panCard;
	}
	public void setPanCard(String panCard) {
		this.panCard = panCard;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public Meter getMeter() {
		return meter;
	}
	public void setMeter(Meter meter) {
		this.meter = meter;
	}
	public Address getAddress() {
		return address;
	}
	public void setAddress(Address address) {
		this.address = address;
	}
	@Override
	public int hashCode() {
		final int prime = 31;
		int result = 1;
		result = prime * result + ((address == null) ? 0 : address.hashCode());
		result = prime * result + customerNo;
		result = prime * result + ((email == null) ? 0 : email.hashCode());
		result = prime * result + ((firstName == null) ? 0 : firstName.hashCode());
		result = prime * result + ((lastName == null) ? 0 : lastName.hashCode());
		result = prime * result + ((meter == null) ? 0 : meter.hashCode());
		result = prime * result + mobileNo;
		result = prime * result + ((panCard == null) ? 0 : panCard.hashCode());
		return result;
	}
	@Override
	public boolean equals(Object obj) {
		if (this == obj)
			return true;
		if (obj == null)
			return false;
		if (getClass() != obj.getClass())
			return false;
		Customer other = (Customer) obj;
		if (address == null) {
			if (other.address != null)
				return false;
		} else if (!address.equals(other.address))
			return false;
		if (customerNo != other.customerNo)
			return false;
		if (email == null) {
			if (other.email != null)
				return false;
		} else if (!email.equals(other.email))
			return false;
		if (firstName == null) {
			if (other.firstName != null)
				return false;
		} else if (!firstName.equals(other.firstName))
			return false;
		if (lastName == null) {
			if (other.lastName != null)
				return false;
		} else if (!lastName.equals(other.lastName))
			return false;
		if (meter == null) {
			if (other.meter != null)
				return false;
		} else if (!meter.equals(other.meter))
			return false;
		if (mobileNo != other.mobileNo)
			return false;
		if (panCard == null) {
			if (other.panCard != null)
				return false;
		} else if (!panCard.equals(other.panCard))
			return false;
		return true;
	}
	@Override
	public String toString() {
		return "Customer [customerNo=" + customerNo + ", mobileNo=" + mobileNo + ", firstName=" + firstName
				+ ", lastName=" + lastName + ", panCard=" + panCard + ", email=" + email + meter.toString()
				+ address.toString();
	}

}
