package com.cg.electricitybillgeneration.util;

import java.util.HashMap;

import com.cg.electricitybillgeneration.beans.Customer;


public class ElectricityUtil {
	public static int CUSTOMER_NO_COUNTER=2000120;

	public static HashMap<Integer, Customer> customers=new HashMap<>();

	public static int getCUSTOMER_NO_COUNTER() {
		return ++CUSTOMER_NO_COUNTER;
	}

}
