package com.cg.electricitybillservices;

import java.util.List;

import com.cg.electricitybilldaoservices.CustomerDao;
import com.cg.electricitybilldaoservices.CustomerDaoImpl;
import com.cg.electricitybillgeneration.beans.Address;
import com.cg.electricitybillgeneration.beans.Bill;
import com.cg.electricitybillgeneration.beans.Customer;
import com.cg.electricitybillgeneration.beans.Meter;
import com.cg.electricitybillgeneration.exception.CustomerDetailsNotFoundException;

public class ElectricityBillServicesImpl implements ElectricityBillServices{
	private CustomerDao customerDao=new CustomerDaoImpl();
	@Override
	public int acceptCustomerDetails(int mobileNo, String firstName, String lastName, String panCard, String email,
			int meterNo, int consumptionUnits, int meterLoad, String phase, int billNo, String billdate,
			String billUnit, String billMonth, int pinCode, int wardNo, String state, String district, String doorNo) {
		Customer customer=new Customer(mobileNo, firstName, lastName, panCard, email, 
				new Meter(meterNo, consumptionUnits, meterLoad, phase, new Bill(billNo, billdate, billUnit, billMonth)), 
				new Address(pinCode, wardNo, state, district, doorNo));
		customer=customerDao.save(customer);
		return customer.getCustomerNo();
	}

	@Override
	public float generateBill(int customerNo) throws CustomerDetailsNotFoundException{
		Customer customer=getCustomerDetails(customerNo);
		if(customer.getMeter().getPhase().equals("single"))
			customer.getMeter().getBill().setFixedCharge(80);
		else if(customer.getMeter().getPhase().equals("three"))
			customer.getMeter().getBill().setFixedCharge(300);
		float energyCharge=0f;
		int consumedUnits=customer.getMeter().getConsumptionUnits();
		customer.getMeter().getBill().setEnergyDuty(consumedUnits*4);
		while(consumedUnits>0) {
			if(consumedUnits>1000) {
				energyCharge+=(consumedUnits-1000)*12.8;
				consumedUnits=1000;
			}
			else if(consumedUnits>500&&consumedUnits<=1000) {
				energyCharge+=(1000-500)*11.8;
				consumedUnits=500;
			}
			else if(consumedUnits>300&&consumedUnits<=500) {
				energyCharge+=(500-300)*11.05;
				consumedUnits=300;
			}
			else if(consumedUnits>100&&consumedUnits<=300) {
				energyCharge+=(300-100)*8.03;
				consumedUnits=100;
			}
			else if(consumedUnits>0&&consumedUnits<=100) {
				energyCharge+=(100-0)*4.30;
				consumedUnits=0;
			}
		}
		customer.getMeter().getBill().setEnergyTax(energyCharge*6/100);
		customer.getMeter().getBill().setBillAmount(energyCharge+customer.getMeter().getBill().getFixedCharge()
				+customer.getMeter().getBill().getEnergyDuty()+customer.getMeter().getBill().getEnergyTax());
		customerDao.update(customer);
		return customer.getMeter().getBill().getBillAmount();
	}

	@Override
	public Customer getCustomerDetails(int customerNo) throws CustomerDetailsNotFoundException {
		Customer customer=customerDao.findOne(customerNo);
		if(customer==null)throw new CustomerDetailsNotFoundException("customer details not found");
		return customer;
	}

	@Override
	public List<Customer> getAllCustomerDetails() {
		return customerDao.findAll();
	}





}
