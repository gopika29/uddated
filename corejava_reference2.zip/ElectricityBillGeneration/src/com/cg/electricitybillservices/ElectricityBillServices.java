package com.cg.electricitybillservices;

import java.util.List;

import com.cg.electricitybillgeneration.beans.Customer;
import com.cg.electricitybillgeneration.exception.CustomerDetailsNotFoundException;

public interface ElectricityBillServices {
	int acceptCustomerDetails(int mobileNo, String firstName, String lastName, String panCard, String email,
			int meterNo, int consumptionUnits, int meterLoad, String phase, int billNo, String billdate, 
			String billUnit, String billMonth,int pinCode, int wardNo, String state, String district, String doorNo);
	float generateBill(int customerNo)throws CustomerDetailsNotFoundException;
	Customer getCustomerDetails(int customerNo)throws CustomerDetailsNotFoundException;
	List<Customer> getAllCustomerDetails();
}
