package com.cg.electricitybillservices.test;
import static org.junit.Assert.*;

import java.util.ArrayList;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;
import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.electricitybillgeneration.beans.Address;
import com.cg.electricitybillgeneration.beans.Bill;
import com.cg.electricitybillgeneration.beans.Customer;
import com.cg.electricitybillgeneration.beans.Meter;
import com.cg.electricitybillgeneration.exception.CustomerDetailsNotFoundException;
import com.cg.electricitybillgeneration.util.ElectricityUtil;
import com.cg.electricitybillservices.ElectricityBillServices;
import com.cg.electricitybillservices.ElectricityBillServicesImpl;



public class ElectricityBillServicesTest {
	public static ElectricityBillServices electricityBillServices;
	@BeforeClass
	public static void setUpTestEnv() {
		electricityBillServices=new ElectricityBillServicesImpl();
	}
	@Before
	public void setUpTestData() {
	Customer customer1=new Customer(2000121, 499494, "gopi", "ankani", "HDH9273", "gopi@gmail.com", 
			new Meter(1793, 900, 3, "single", new Bill(37927, "10-09-2018", "doh937973", "sep")), 
			new Address(35435, 2, "maharashtra", "pune", "4-111"));
	Customer customer2=new Customer(2000122, 499494, "gopi", "ankani", "HDH9273", "gopi@gmail.com", 
			new Meter(1793, 900, 3, "single", new Bill(37927, "10-09-2018", "doh937973", "sep")), 
			new Address(35435, 2, "maharashtra", "pune", "4-111"));
		ElectricityUtil.customers.put(customer1.getCustomerNo(),customer1);
		ElectricityUtil.customers.put(customer2.getCustomerNo(),customer2);
		ElectricityUtil.CUSTOMER_NO_COUNTER=2000123;
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedCustomerNo=2000123;
		int actualCustomerNo=electricityBillServices.acceptCustomerDetails(4534565, "sadhik", "shaik", "GDT63286","shaik@gmail.com", 840834, 1200, 1, "three",123423, 
				"10-09-2018", "48shfhh", "sep", 254543, 2, "maharashtra", "pune", "234-a");
		Assert.assertEquals(expectedCustomerNo, actualCustomerNo);
	}
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssoiciateId()throws CustomerDetailsNotFoundException{
		electricityBillServices.getCustomerDetails(12223);
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()throws CustomerDetailsNotFoundException{
	Customer expectedCustomer=new Customer(2000121, 499494, "gopi", "ankani", "HDH9273", "gopi@gmail.com", 
				new Meter(1793, 900, 3, "single", new Bill(37927, "10-09-2018", "doh937973", "sep")), 
				new Address(35435, 2, "maharashtra", "pune", "4-111"));
		Customer actualCustomer=electricityBillServices.getCustomerDetails(2000121);
		Assert.assertEquals(expectedCustomer, actualCustomer);
	}
	@Test(expected=CustomerDetailsNotFoundException.class)
	public void testCalcualteNetSalaryForInvalidAssociateId()throws CustomerDetailsNotFoundException{
		electricityBillServices.getCustomerDetails(12223);
	}
	@Test
	public void testCalcualteNetSalaryForvalidAssociateId()throws CustomerDetailsNotFoundException{
		float expectedBillAmount=38066.67f;
		float actualBillAmount=electricityBillServices.generateBill(1222);
		Assert.assertEquals(expectedBillAmount, actualBillAmount, 1000);
	}
	@Test
	public void testForGetAllAssociateDetails() {
		ArrayList<Customer> expectedCustomerList=new ArrayList<>(ElectricityUtil.customers.values());
		ArrayList<Customer> actualCustomerList=(ArrayList<Customer>) electricityBillServices.getAllCustomerDetails();
		Assert.assertEquals(expectedCustomerList, actualCustomerList);
	}
	@After
	public void tearDownTestData() {
		ElectricityUtil.CUSTOMER_NO_COUNTER=2000120;
		ElectricityUtil.customers.clear();
	}
	@AfterClass
	public static void tearDownTestEnv() {
		electricityBillServices=null;
	}



}
