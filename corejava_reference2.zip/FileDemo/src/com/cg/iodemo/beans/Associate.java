package com.cg.iodemo.beans;

import java.io.Serializable;

public class Associate implements Serializable{
	private static int num=100;
	private int associateId;
	transient int basicSalary;
	private String frstName,lastName;
	public Associate() {
		// TODO Auto-generated constructor stub
	}
	public Associate(int associateId, int basicSalary, String frstName, String lastName) {
		super();
		this.associateId = associateId;
		this.basicSalary = basicSalary;
		this.frstName = frstName;
		this.lastName = lastName;
	}
	
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public int getBasicSalary() {
		return basicSalary;
	}
	public void setBasicSalary(int basicSalary) {
		this.basicSalary = basicSalary;
	}
	public String getFrstName() {
		return frstName;
	}
	public void setFrstName(String frstName) {
		this.frstName = frstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	@Override
	public String toString() {
		return "Associate [associateId=" + associateId + ", basicSalary=" + basicSalary + ", frstName=" + frstName
				+ ", lastName=" + lastName + "]";
	}

}
