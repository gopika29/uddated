package com.cg.lab3.client;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Scanner;

import com.cg.lab3.bean.DifferenceBetweenDates;
import com.cg.lab3.bean.StringDictionaryAndUpperCase;
import com.cg.lab3.bean.StringOperations;
import com.cg.lab3.bean.UserNameValidation;

public class MainClass {

	public static void main(String[] args) {
		Scanner ip=new Scanner(System.in);
		String str="gopika";
		System.out.println("enter the method");
		int num=ip.nextInt();
		switch (num) {
		case 1:
			System.out.println(str.concat(str));
			break;
		case 2:
			System.out.println(StringOperations.replaceOddChars(str));
			break;
		case 3:
			System.out.println(StringOperations.removeDuplicateChars(str));
			break;
		case 4:
			System.out.println(StringOperations.changeOddCharsToUpper(str));
			break;
		default:
			break;
		}
		System.out.println(StringOperations.positiveString("ANT"));
		DifferenceBetweenDates dateDiff=new DifferenceBetweenDates();
		System.out.printf("\nDifference is %d years, %d months and %d days old\n\n", 
				dateDiff.diff.getYears(), dateDiff.diff.getMonths(), dateDiff.diff.getDays());
		dateDiff.differenceBetweenDates();
		dateDiff.expiryDate(LocalDate.of(2017, 10, 29));
		dateDiff.zoneCurrentDate(ZoneId.of("Brazil/East"));
		UserNameValidation user=new UserNameValidation();
		System.out.println(user.userNameValid("gopi_job"));
		String [] strArr= {"mango","telugu","apple","google"};
		StringDictionaryAndUpperCase.sort(strArr);
		StringDictionaryAndUpperCase.printArray(strArr);
		StringDictionaryAndUpperCase.halfStringsToUpperCase(strArr);
		StringDictionaryAndUpperCase.printArray(strArr);
	}

}
