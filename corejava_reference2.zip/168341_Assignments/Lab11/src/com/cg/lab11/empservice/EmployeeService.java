package com.cg.lab11.empservice;

import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Map;
import java.util.stream.Collectors;

import com.cg.lab11.beans.Department;
import com.cg.lab11.beans.Employee;
import com.cg.lab11.comparator.EmployeeComparator;

public class EmployeeService {
	private static ArrayList<Employee> empList=new ArrayList<>();
	public void addEmployee(int employeeId, String firstName, String lastName, String email, String phoneNumber,
			String designation, LocalDate hiredate, double salary, int departmentId, int managerId, String departmentName) {
		Employee emp=new Employee(employeeId, firstName, lastName, email, phoneNumber
				, designation, hiredate, salary, new Department(departmentId, managerId, departmentName));
		empList.add(emp);
	}
	public double sumOfSalaryofAll() {
		double totalSalaryExpense = empList.stream()
				.map(emp -> emp.getSalary())
				.reduce(0.00,(a,b) -> a+b);
		return totalSalaryExpense;
	}
	public long empCountInDepartment() {
		long empCount=empList.stream()
		.map(emp -> emp.getDepartment().getDepartmentName())
		.count();
		return empCount;
	}
	
}
