package com.cg.lab11.client;

import com.cg.lab11.functionalinterface.PowerInterface;

public class MainClass {
	public static void main(String args[]) {
		PowerInterface ref1=(x,y)->(int)Math.pow((double)x, (double)y);
		System.out.println(ref1.power(2, 3));
	}

}
