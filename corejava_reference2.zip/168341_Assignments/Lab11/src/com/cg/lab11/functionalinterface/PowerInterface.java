package com.cg.lab11.functionalinterface;
@FunctionalInterface
public interface PowerInterface {
	public int power(int x,int y);
}
