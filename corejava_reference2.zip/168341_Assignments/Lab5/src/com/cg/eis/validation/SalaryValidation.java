package com.cg.eis.validation;

import com.cg.eis.exception.SalaryNotValidException;

public class SalaryValidation {
	public static boolean checkSalary(int salary) throws SalaryNotValidException {
		if(salary<=3000)throw new SalaryNotValidException("salary should be greater than 3000");
		return true;
	}
}
