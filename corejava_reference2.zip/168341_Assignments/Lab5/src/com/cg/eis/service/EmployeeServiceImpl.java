package com.cg.eis.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

import com.cg.eis.bean.Employee;



public class EmployeeServiceImpl implements EmployeeService{

	@Override
	public String setInsuranceScheme(int salary, String designation) {

		if(designation.equals("analyst")&&salary<=20000)
			return "health insurance";
		else if(designation.equals("analyst")&&salary>20000&&salary<=30000)
			return "Vehicle insurance";
		else if(designation.equals("developer")&&salary>30000&&salary<=40000)
			return "Workers' compensation insurance";
		else if(designation.equals("seniordeveloper")&&salary>40000)
			return "property insurance";
		else
			return  "all schemes";

	}
	HashMap<Integer,Employee> list = new HashMap<>();
	@Override
	public void addEmployee(Employee emp) {
		list.put(emp.getId(), emp);
	}
	@Override
	public boolean deleteEmployee(int id) {
		if(list.containsKey(id)) {
			list.remove(id);
			return true;
		}
		else return false;
	}
	@Override
	public List<Employee> getAllEmployees() {
		return (ArrayList<Employee>) list.values();
	}



}
