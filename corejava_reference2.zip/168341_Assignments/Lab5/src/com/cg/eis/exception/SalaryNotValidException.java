package com.cg.eis.exception;

public class SalaryNotValidException extends Exception{

	public SalaryNotValidException() {
		super();
	}

	public SalaryNotValidException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
	}

	public SalaryNotValidException(String message, Throwable cause) {
		super(message, cause);
	}

	public SalaryNotValidException(String message) {
		super(message);
	}

	public SalaryNotValidException(Throwable cause) {
		super(cause);
	}

}
