package com.cg.lab4.beans;

import com.cg.lab4.util.AccountUtil;

public abstract class Account {
	private long accNum;
	private double balance;
	private Person person;
	public Account() {}
	public Account(double balance, Person person) {
		super();
		this.balance = balance;
		this.person = person;
	}
	public Long getAccNum() {
		return accNum;
	}
	public void setAccNum(long accNum) {
		this.accNum = accNum;
	}
	public double getBalance() {
		return balance;
	}
	public void setBalance(double balance) {
		this.balance = balance;
	}
	public Person getPerson() {
		return person;
	}
	public void setPerson(Person person) {
		this.person = person;
	}
	
	public abstract void deposit(double depositAmount);
	
	public abstract void withdraw(double withdrawAmount);
	
	@Override
	public String toString() {
		return "accNum=" + accNum + ", balance=" + balance + ", person=" + person.toString()+"\n";
	}
	
	
}
