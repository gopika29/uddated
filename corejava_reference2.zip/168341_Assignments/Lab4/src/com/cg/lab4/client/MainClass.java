package com.cg.lab4.client;

import com.cg.lab4.beans.Account;
import com.cg.lab4.beans.CurrentAccount;
import com.cg.lab4.beans.Person;
import com.cg.lab4.beans.SavingsAccount;
import com.cg.lab4.exception.AgeNotValidException;
import com.cg.lab4.util.AccountUtil;
import com.cg.lab4.validation.AgeValidation;

public class MainClass {

	public static void main(String[] args) {
		//before inheritance
	/*	Account smithAccount=new Account(2000, new Person("smith", 34));
		smithAccount.setAccNum(AccountUtil.getAccountNumber());
		Account kathyAccount=new Account(3000, new Person("kathy", 32));
		kathyAccount.setAccNum(AccountUtil.getAccountNumber());
		System.out.print("smith Account: "+smithAccount.toString());
		System.out.print("kathy Account: "+	kathyAccount.toString());
		smithAccount.deposit(2000);
		System.out.println("Smith balance after deposit: "+smithAccount.getBalance());
		kathyAccount.withdraw(1000);
		System.out.println("Kathy balance after withdrw: "+kathyAccount.getBalance());*/
		//after inheritance
		Account smith=new CurrentAccount(2000, new Person("smith", 34));
		//lab6.2
		try {
			if(AgeValidation.checkAge(smith.getPerson().getAge()))
				System.out.println("details are correct");
		} catch (AgeNotValidException e) {
			e.printStackTrace();
		}
		smith.setAccNum(AccountUtil.getAccountNumber());
		Account kathy=new SavingsAccount(3000, new Person("kathy", 32));
		kathy.setAccNum(AccountUtil.getAccountNumber());
		smith.deposit(2000);
		System.out.println("smith bal after deposit "+smith.getBalance());
		kathy.withdraw(3000);
		kathy.withdraw(2000);
		System.out.println("kathy bal after withdraw "+kathy.getBalance());

	}

}
