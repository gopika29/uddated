package com.cg.lab4.validation;

import com.cg.lab4.exception.AgeNotValidException;

public class AgeValidation {
	public static boolean checkAge(float age) throws AgeNotValidException {
		if(age<15) throw new AgeNotValidException("age is minimum 15");
		return true;
	}
}
