package com.cg.lab2.bean;

public class Person {
	private String firstName,lastName;
	private Gender gender;
	private int age;
	private float weight;
	private long phoneNo;

	
	public Person(String firstName, String lastName, Gender gender, int age, float weight) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
	}

	public Person(String firstName, String lastName, Gender gender, int age, float weight, long phoneNo) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.gender = gender;
		this.age = age;
		this.weight = weight;
		this.phoneNo = phoneNo;
		printGender();
	}

	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public Gender getGender() {
		return gender;
	}
	public void setGender(Gender gender) {
		this.gender = gender;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public float getWeight() {
		return weight;
	}
	public void setWeight(float weight) {
		this.weight = weight;
	}

	private long getPhoneNo() {
		return phoneNo;
	}

	private void setPhoneNo(long phoneNo) {
		this.phoneNo = phoneNo;
	}

	@Override
	public String toString() {
		return "Person [firstName=" + firstName + ", lastName=" + lastName + ", gender=" + gender + ", age=" + age
				+ ", weight=" + weight + ", phoneNo=" + phoneNo + "]";
	}
	

    public final void printGender() {
        System.out.println(gender.name());
    }   

}