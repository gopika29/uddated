package com.cg.lab2.client;

import com.cg.lab2.bean.NegativeOrPositive;

public class MainClass {

	public static void main(String[] args) {
		System.out.println(NegativeOrPositive.checkingForSign(Integer.parseInt(args[0])));
	}
}
