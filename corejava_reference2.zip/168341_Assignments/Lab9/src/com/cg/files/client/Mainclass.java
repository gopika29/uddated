package com.cg.files.client;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.IOException;

import com.cg.files.bean.EvenOddFromFileUsingScanner;
import com.cg.files.bean.ReadFileWriteInReverse;

public class Mainclass {
	public static void main(String args[]) {
		/*File fromFile=new File("D:\\table.java") ;
		File toFile=new File("D:\\table.java");
		try {
			ReadFileWriteInReverse.readFileAndWriteInReverse(fromFile, toFile);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		} catch (IOException e) {
			e.printStackTrace();
		}*/
		File file=new File("//home//gopa//eclipse-workspace//Lab9//numbers.txt");
		try {
			EvenOddFromFileUsingScanner.evenOdd(file);
		} catch (FileNotFoundException e) {
			e.printStackTrace();
		}
	}
}
