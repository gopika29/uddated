package com.cg.files.bean;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

public class ReadFileWriteInReverse {
	public static void readFileAndWriteInReverse(File fromFile,File toFile) throws FileNotFoundException, IOException {
		ArrayList list = new ArrayList();
		try(BufferedReader srcReader =new BufferedReader(new FileReader(fromFile))){
			try(BufferedWriter destWriter=new BufferedWriter(new FileWriter(toFile))){
				String data="";
				while((data=srcReader.readLine())!=null)
					list.add(data);
				Collections.reverse(list);
				for (Iterator i = list.iterator(); i.hasNext();) {
					destWriter.write((String)i.next());
				}
				System.out.println("File written on "+toFile.getAbsolutePath());
			}
		}
	}
}
