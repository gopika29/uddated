package com.cg.lab8.electronic;

public class ElectronicShop {
	public synchronized void customer() throws InterruptedException {
		System.out.println("Customer giving products to billing person\n");
		this.notify();
	}
	public synchronized void billing() throws InterruptedException {
		System.out.println("Billing person bills the products");
		this.wait();
	}

}
