package com.cg.lab8.thread;

import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CopyDataThread extends Thread{
	public void run() {
		File file=new File("D:\\gankani_GopaKumari_Ankani\\corejava\\Lab8\\target.txt");
		FileReader inputStream = null;
        FileWriter outputStream = null;
        try {
        	if(!file.exists())
				file.createNewFile();
            inputStream = new FileReader("D:\\gankani_GopaKumari_Ankani\\corejava\\Lab8\\source.txt");
            outputStream = new FileWriter("D:\\gankani_GopaKumari_Ankani\\corejava\\Lab8\\target.txt");
            int c,m=10,count=0;
            while ((c = inputStream.read()) != -1) {
                if(count==m) {
                	System.out.println("10 characters copied");
                	Thread.sleep(5000);
                	m+=10;
                }
                outputStream.write(c);
                count++;
            }
            if (inputStream != null) {
                inputStream.close();
            }
            if (outputStream != null) {
                outputStream.close();
            }
        } catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		} 
	}
}
