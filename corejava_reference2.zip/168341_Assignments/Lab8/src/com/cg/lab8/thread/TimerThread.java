package com.cg.lab8.thread;

import java.util.Timer;

public class TimerThread implements Runnable{

	@Override
	public void run() {
		Thread t=Thread.currentThread();
		try {
			Thread.sleep(10000);
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
		System.out.println("timer has been refreshed after 10 sec's"+new Timer(t.getName()));
	}

}
