package com.cg.collectiondemo.beans;

@FunctionalInterface
public interface Condition<T> {
	boolean startWith(T associate);
}
