package com.cg.collectiondemo.beans;

import java.util.Comparator;

public class AssociateComparitor implements Comparator<Associate>{

	@Override
	public int compare(Associate associate1, Associate associate2) {
		return associate1.getFirstName().compareTo(associate2.getFirstName());
	}

}
