package com.cg.collectiondemo.client;

import com.cg.collectiondemo.collection.ListClassDemo;

public class MainClass {
	public static void main(String args[]) {
		ListClassDemo.arrayListClassDemo();
	}
}
