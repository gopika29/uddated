package com.cg.collectiondemo.collection;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Iterator;
import java.util.LinkedList;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Predicate;
import java.util.stream.Stream;

import com.cg.collectiondemo.beans.Associate;
import com.cg.collectiondemo.beans.AssociateComparitor;
import com.cg.collectiondemo.beans.Condition;

public class ListClassDemo {

	public static void arrayListClassDemo() {
		/*ArrayList<Associate> associates=new ArrayList<>();
		
		//insert
		associates.add(new Associate(111,50000,"gopi","ankani"));
		associates.add(new Associate(113,25000,"sadhik","shaik"));
		associates.add(new Associate(114,39000,"teja","hemanth"));
		associates.add(new Associate(112,20000,"raja","ankani"));
		
		//search
		
		Associate associateToBeSearch=new Associate(113, 25000, "sadhik", "shaik");
		
		int idx=associates.indexOf(associateToBeSearch);
		System.out.println(idx);
		//remove
		System.out.println(associates.remove(2));
		//sort
		Collections.sort(associates);
		System.out.println(associates);
		
		AssociateComparitor comparitor=new AssociateComparitor();
		Collections.sort(associates, comparitor);
		System.out.println(associates);
		//iteration
		for (Associate associate : associates)
			System.out.println(associate);*/
			
		LinkedList<Associate> associates1=new LinkedList<>();
		
		//insert
		associates1.add(new Associate(111,50000,"gopi","ankani"));
		associates1.add(new Associate(113,25000,"sadhik","shaik"));
		associates1.add(new Associate(114,39000,"teja","hemanth"));
		associates1.add(new Associate(112,20000,"raja","ankani"));
		associates1.add(new Associate(114,39000,"teja","hemanth"));
		associates1.add(new Associate(112,20000,"raja","ankani"));
		
	/*	//search
		
		Associate associateToBeSearch1=new Associate(113, 25000, "sadhik", "shaik");
		
		int idx1=associates1.indexOf(associateToBeSearch1);
		System.out.println(idx1);
		//remove
		System.out.println(associates1.remove(2));
		//sort
		Collections.sort(associates1);
		System.out.println(associates1);
		
		AssociateComparitor comparitor1=new AssociateComparitor();
		Collections.sort(associates1, comparitor1);
		System.out.println(associates1);
		
		Comparator<Associate> associateComparator=(a1,a2)->a1.getBasicSalary()-a2.getBasicSalary();
		Collections.sort(associates1, associateComparator);
		System.out.println(associates1);
		Collections.sort(associates1, (a1,a2)->a1.getFirstName().compareTo(a2.getFirstName()));
		System.out.println(associates1);
		//startsWith'a'
		//printEmployeeDetails1(associates1, (a)->a.getFirstName().startsWith("g"));
		
		//printEmployeeDetails2(associates1, (a)->a.getFirstName().startsWith("s"),(a)->System.out.println(a));
		//iteration
		for (Associate associate : associates1)
			System.out.println(associate);
		associates1.forEach((a)->System.out.println(a));*/
		
		Stream<Associate> stream1=associates1.stream();
		Stream<Associate> stream2=stream1.distinct();
		Stream<Associate> stream3=stream2.filter((a)->a.getFirstName().startsWith("g"));
		//System.out.println(stream3.count());
		stream3.forEach((a)->System.out.println(a));
		
		associates1.stream()
		.distinct()
		.filter((a)->a.getFirstName().startsWith("g"))
		.forEach((a)->System.out.println(a));
		System.out.println(associates1.stream().map(associate->associate.getAssociateId()));
		
	}
	/*private static void printEmployeeDetails1(List<Associate> associates1,Condition condition) {
		for (Associate associate : associates1) {
			if (condition.startWith(associate))
				System.out.println(associate);
		}
	}
	private static void printEmployeeDetails2(List<Associate> associates1,Predicate<Associate>predicate,Consumer<Associate>consumer){
		for (Associate associate : associates1) {
			if(predicate.test(associate))
				consumer.accept(associate);
		}

	}*/
}
