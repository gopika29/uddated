package com.cg.capstore.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;

import com.cg.capstore.beans.Category;
import com.cg.capstore.beans.Inventory;
import com.cg.capstore.beans.Merchant;
import com.cg.capstore.beans.Product;
import com.cg.capstore.exceptions.CapstoreException;
import com.cg.capstore.services.CapstoreServices;

@Controller
public class CapStoreController {
	@Autowired
	CapstoreServices capstoreServices;

	public CapstoreServices getCapstoreServices() {
		return capstoreServices;
	}
	public void setCapstoreServices(CapstoreServices capstoreServices) {
		this.capstoreServices = capstoreServices;
	}
	Merchant merchant;Category category;
	@RequestMapping(value="/HomePage")
	public String goToHomePage() {
		return "HomePage";
	}
	@RequestMapping(value="/MerchantPage",method=RequestMethod.GET)
	public String goToMerchantPage(Model model) {
		model.addAttribute("Merchant", new Merchant());
		return "GoToInventoryPage";
	}
	@RequestMapping(value="/EditItems",method=RequestMethod.POST)
	public String goToMerchantInventory(@ModelAttribute(value="Merchant")Merchant merchant,Model model,BindingResult result){
		if(result.hasErrors())
			return "MerchantInventory";
		this.merchant=capstoreServices.findOne(merchant.getMerchant_id());
		model.addAttribute("Merchant",this.merchant);
		return "MerchantInventory";


	}
	@RequestMapping(value="/showAllCategory",method=RequestMethod.GET)
	public String removeCategoryPage(Model model) {
		model.addAttribute("CategoryList", capstoreServices.findAllCategories());
		return "AllCategories";
	}
	@RequestMapping(value="/addCategory",method=RequestMethod.GET)
	public String addCategoryPage(Model model) {
		model.addAttribute("Category", new Category());
		return "AddCategory";
	}
	@RequestMapping(value="/add",method=RequestMethod.POST)
	
	public String addCategory(@ModelAttribute(value="Category")Category category,Model model) {
		capstoreServices.addCategory(new Category(category.getCategoryName(), category.getType()), merchant);
		model.addAttribute("message", "category added");
		return "AddCategory";

	}
	@RequestMapping(value="/editItems",method=RequestMethod.GET)

	public String goToEditItemsPage(Model model) {
		List<Product> products=capstoreServices.findAllProductsOfInventory(merchant.getMerchant_id());

		model.addAttribute("productList", products);
		return "EditItems";


	}
	@RequestMapping(value="/removeItems",method=RequestMethod.GET)

	public String removeProducts(@RequestParam(value="productId")String productId,Model model) {
		capstoreServices.removeProduct(productId);
		model.addAttribute("productList", capstoreServices.findAllProductsOfInventory(merchant.getMerchant_id()));
		model.addAttribute("message", "deleted successfully");
		return "EditItems";


	}
	@RequestMapping(value="/EditProduct",method=RequestMethod.GET)

	public String goToUpdatePage(@RequestParam(value="productId")String productId,Model model) {
		Product product=capstoreServices.getOneProduct(productId);

		model.addAttribute("Product", product);
		return "EditProductPage";	

	}
	@RequestMapping(value="/UpdateProduct",method=RequestMethod.POST)

	public String updateProduct(@ModelAttribute(value="Product")Product product,Model model) {
		capstoreServices.updateProduct(product);
		model.addAttribute("message", "updated successfully");
		return "EditProductPage";

	}

	@RequestMapping(value="/goToAddProductPage",method=RequestMethod.GET)
	
	public String goToAddProductPage(Model model,@RequestParam(value="categoryId")int categoryId) {
		category=capstoreServices.findCategory(categoryId);
		model.addAttribute("product", new Product());
		return "AddProduct";
	}
	@RequestMapping(value="/addProduct",method=RequestMethod.POST)
	
	public String addProduct(Model model,@ModelAttribute(value="product")Product product,BindingResult result) {
		if(result.hasErrors())
			return "AddProduct";
		capstoreServices.addProduct(new Product(product.getProduct_name(),
				product.getDescription(), product.getPrice(), product.getSold_quantity(), product.getAvail_stock(),
				product.getDiscount(), product.getNo_of_views()), merchant, category);
		model.addAttribute("message", "product added");
		return "AddProduct";
	}
	@RequestMapping(value="/AdminPage",method=RequestMethod.GET)
	public String goToAdminPage(Model model) {
		List<Inventory> inventories=capstoreServices.findAll();
		model.addAttribute("InventoryList", inventories);
		return "AdminPage";
	}

	@RequestMapping(value="/showCategoriesofMerchant",method=RequestMethod.GET)
	@ExceptionHandler(CapstoreException.class)
	public String showAllCategoriesOfMerchant(@RequestParam(value="merchantId")String merchantId,Model model){
		merchant=capstoreServices.findOne(merchantId);
		model.addAttribute("Merchant",merchant);
		return "MerchantInventory";
	}
	
	@RequestMapping(value="/AdminCategoryPage",method=RequestMethod.GET)
	public String showAllCategoriesAdmin(Model model) {
		model.addAttribute("categoryList", capstoreServices.findAllCategories());
		return "CategoriesPage";
	}
	
	@RequestMapping(value="/remove",method=RequestMethod.GET)
	public String removeCategory(@RequestParam(value="categoryId")int categoryId,Model model) {
		capstoreServices.removeCategory(categoryId);
		model.addAttribute("categoryList", capstoreServices.findAllCategories());
		model.addAttribute("message", "deleted successfully");
		return "CategoriesPage";
	}

}
