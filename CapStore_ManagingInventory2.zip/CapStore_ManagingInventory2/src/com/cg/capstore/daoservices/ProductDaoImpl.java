package com.cg.capstore.daoservices;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Product;

@Repository
@Transactional
public class ProductDaoImpl implements ProductDao{
	@PersistenceContext
	EntityManager entityManager;

	public EntityManager getEntityManager() {
		return entityManager;
	}

	public void setEntityManager(EntityManager entityManager) {
		this.entityManager = entityManager;
	}

	@SuppressWarnings("unchecked")
	@Override
	public List<Product> findAllProductsBasedOnInventory(int inventoryId) {
		return entityManager.
				createQuery("select p from Product p where inventoryId="+inventoryId).getResultList();
	}

	@Override
	public boolean removeProduct(String productId) {
		entityManager.remove(entityManager.find(Product.class, productId));
		entityManager.flush();
		return true;
	}

	@Override
	public Product findOne(String productId) {
		return entityManager.find(Product.class, productId);
	}

	@Override
	public boolean updateProduct(Product product) {
		entityManager.merge(product);
		entityManager.flush();
		return true;
	}

	@Override
	public Product addProduct(Product product) {
		entityManager.merge(product);
		entityManager.flush();
		return product;
	}
	
}
