package com.cg.capstore.daoservices;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.transaction.Transactional;

import org.springframework.stereotype.Repository;

import com.cg.capstore.beans.Merchant;
@Repository
@Transactional
public class MerchantDaoImpl implements MerchantDao{
	@PersistenceContext
	EntityManager entityManager;

	@Override
	public Merchant findOne(String merchantId) {
		return entityManager.find(Merchant.class, merchantId);
	}
	
}
