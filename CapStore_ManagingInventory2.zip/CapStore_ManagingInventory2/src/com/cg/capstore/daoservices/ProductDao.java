package com.cg.capstore.daoservices;

import java.util.List;

import com.cg.capstore.beans.Product;

public interface ProductDao {
	public List<Product> findAllProductsBasedOnInventory(int inventoryId);
	public boolean removeProduct(String productId);
	public Product findOne(String productId);
	public boolean updateProduct(Product product);
	public Product addProduct(Product product);
}
