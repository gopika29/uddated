package com.cg.capstore.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.capstore.beans.Category;
import com.cg.capstore.beans.Inventory;
import com.cg.capstore.beans.Merchant;
import com.cg.capstore.beans.Product;
import com.cg.capstore.daoservices.CategoryDao;
import com.cg.capstore.daoservices.InventoryDao;
import com.cg.capstore.daoservices.MerchantDao;
import com.cg.capstore.daoservices.ProductDao;
import com.cg.capstore.exceptions.CapstoreException;
@Service
public class CapstoreServicesImpl implements CapstoreServices{
	@Autowired
	MerchantDao merchantDao;
	@Autowired
	InventoryDao inventoryDao;
	@Autowired
	CategoryDao categoryDao;
	@Autowired
	ProductDao productDao;
	static int productId=26;
	public MerchantDao getMerchantDao() {
		return merchantDao;
	}
	public void setMerchantDao(MerchantDao merchantDao) {
		this.merchantDao = merchantDao;
	}
	public InventoryDao getInventoryDao() {
		return inventoryDao;
	}



	public void setInventoryDao(InventoryDao inventoryDao) {
		this.inventoryDao = inventoryDao;
	}



	@Override
	public Merchant findOne(String merchantId) {
		Merchant merchant=merchantDao.findOne(merchantId);
		if(merchant==null) throw new CapstoreException("merchant not found");
		return merchant;
	}



	@Override
	public Inventory findInventoryOfMerchant(String merchantId) {
		Inventory inventory1=null;
		List<Inventory> inventories=inventoryDao.getInventoryId();
		for (Inventory inventory : inventories) {
			if(inventory.getMerchant().getMerchant_id().equals(merchantId))
				inventory1=inventory;
		}
		if(inventory1==null) throw new CapstoreException("inventory not found");
		return inventory1;
	}



	
	@Override
	public Category findCategory(int categoryId) {
		Category category=categoryDao.findOne(categoryId);
		if(category==null) throw new CapstoreException("no Category found");
		return category;
	}



	@Override
	public boolean removeCategory(int categoryId) {
		return categoryDao.removeCategory(categoryId);
	}



	@Override
	public boolean addCategory(Category category, Merchant merchant) {
		return categoryDao.addCategory(category);
	}



	@Override
	public List<Product> findAllProductsOfInventory(String merchantId) {
		return productDao.findAllProductsBasedOnInventory(this.findInventoryOfMerchant(merchantId).getInventory_id());
	}



	@Override
	public boolean removeProduct(String productId) {
		return productDao.removeProduct(productId);
	}



	@Override
	public Product getOneProduct(String productId) {
		return productDao.findOne(productId);
	}



	@Override
	public boolean updateProduct(Product product) {
		return productDao.updateProduct(product);
	}



	@Override
	public List<Inventory> findAll() {
		return inventoryDao.getInventoryId();
	}



	@Override
	public Product addProduct(Product product, Merchant merchant, Category category) {
		product.setInventory(this.findInventoryOfMerchant(merchant.getMerchant_id()));
		product.setCategory(category);
		product.setProduct_id("p"+ ++productId);
		return productDao.addProduct(product);
	}



	@Override
	public List<Category> findAllCategories() {
		return categoryDao.findAll();
	}

}
