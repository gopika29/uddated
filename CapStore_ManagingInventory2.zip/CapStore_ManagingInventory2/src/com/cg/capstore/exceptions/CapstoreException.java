package com.cg.capstore.exceptions;

@SuppressWarnings("serial")
public class CapstoreException extends RuntimeException{

	private String exceptionMsg;
	   
	   public CapstoreException(String exceptionMsg) {
	      this.exceptionMsg = exceptionMsg;
	   }
	   public String getExceptionMsg(){
	      return this.exceptionMsg;
	   }
	   public void setExceptionMsg(String exceptionMsg) {
	      this.exceptionMsg = exceptionMsg;
	   }

}
