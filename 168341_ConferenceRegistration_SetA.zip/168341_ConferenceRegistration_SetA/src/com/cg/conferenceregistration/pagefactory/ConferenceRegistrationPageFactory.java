package com.cg.conferenceregistration.pagefactory;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.CacheLookup;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationPageFactory {
	WebDriver driver;

	public ConferenceRegistrationPageFactory(WebDriver driver) {
		super();
		this.driver = driver;
		PageFactory.initElements(driver, this);
	}
	//coference details enter page------------------------
	@FindBy(id="txtFirstName")
	@CacheLookup
	WebElement firstName;
	
	@FindBy(id="txtLastName")
	@CacheLookup
	WebElement lastName;
	
	@FindBy(id="txtEmail")
	@CacheLookup
	WebElement email;
	
	@FindBy(id="txtPhone")
	@CacheLookup
	WebElement phoneNo;
	
	@FindBy(name="size")
	@CacheLookup
	WebElement peopleAttend;
	
	@FindBy(xpath=".//*[@id='txtAddress1']")
	@CacheLookup
	WebElement plotNo;
	
	@FindBy(id="txtAddress2")
	@CacheLookup
	WebElement areaName;
	
	@FindBy(name="city")
	@CacheLookup
	WebElement city;
	
	@FindBy(name="state")
	@CacheLookup
	WebElement state;
	@FindBy(xpath="html/body/form/table/tbody/tr[12]/td[2]/input")
	@CacheLookup
	WebElement memberRadio;
	@FindBy(xpath="html/body/form/table/tbody/tr[13]/td[2]/input")
	@CacheLookup
	WebElement nonMemberRadio;
	@FindBy(linkText="Next")
	@CacheLookup
	WebElement nextLink;
	
	//payment page elements-----------------------------
	@FindBy(id="txtCardholderName")
	@CacheLookup
	WebElement cardHolderName;
	
	@FindBy(id="txtDebit")
	@CacheLookup
	WebElement debitCardNo;
	
	@FindBy(id="txtCvv")
	@CacheLookup
	WebElement cvv;
	@FindBy(id="txtMonth")
	@CacheLookup
	WebElement expiryMonth;
	@FindBy(id="txtYear")
	@CacheLookup
	WebElement expiryYear;
	
	@FindBy(id="btnPayment")
	@CacheLookup
	WebElement paymentButton;
	
	//functions to use conference registration elements-------------------------------
	public void setDriver(WebDriver driver) {
		this.driver = driver;
	}
	public void setFirstName(String firstName) {
		this.firstName.sendKeys(firstName);
	}
	public void setLastName(String lastName) {
		this.lastName.sendKeys(lastName);
	}
	public void setEmail(String email) {
		this.email.sendKeys(email);
	}
	public void setPhoneNo(String phoneNo) {
		this.phoneNo.sendKeys(phoneNo);
	}
	public void setPeopleAttend(String peopleAttend) {
		Select peopledropDown=new Select(this.peopleAttend);
		peopledropDown.selectByVisibleText(peopleAttend);
	}
	public void setPlotNo(String plotNo) {
		this.plotNo.sendKeys(plotNo);
	}
	public void setAreaName(String areaName) {
		this.areaName.sendKeys(areaName);
	}
	public void setCity(String city) {
		Select citydropDown=new Select(this.city);
		citydropDown.selectByValue(city);
	}
	public void setState(String state) {
		Select statedropDown=new Select(this.state);
		statedropDown.selectByValue(state);
	}
	public void setMemberRadio() {
		this.memberRadio.click();
	}
	public void setNonMemberRadio() {
		this.nonMemberRadio.click();
	}

	public void setNextLink() {
		this.nextLink.click();
	}
	//functions for payment page web elements------------------
	public void setCardHolderName(String cardHolderName) {
		this.cardHolderName.sendKeys(cardHolderName);
	}
	
	public void setDebitCardNo(String debitCardNo) {
		this.debitCardNo.sendKeys(debitCardNo);
	}
	
	public void setCvv(String cvv) {
		this.cvv.sendKeys(cvv);
	}

	public void setExpiryMonth(String expiryMonth) {
		this.expiryMonth.sendKeys(expiryMonth);
	}
	
	public void setExpiryYear(String expiryYear) {
		this.expiryYear.sendKeys(expiryYear);
	}

	public void setPaymentButton() {
		this.paymentButton.click();
	}
	
	
}
