package com.cg.conferenceregistration.stepdefinition;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.regex.Pattern;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import com.cg.conferenceregistration.pagefactory.ConferenceRegistrationPageFactory;

import cucumber.api.DataTable;
import cucumber.api.java.After;
import cucumber.api.java.Before;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class ConferenceRegistrationStepDefinition {
	private WebDriver driver;
	private ConferenceRegistrationPageFactory conferenceRegistrationPageFactory;
	String title;
	@Before
	public void openBrowser() {
		String driverPath = "D:\\gankani_GopaKumari_Ankani\\BDD\\Selenium\\chromedriver_win32\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
	}
	@Given("^user is on conference registration page$")
	public void user_is_on_conference_registration_page() throws Throwable {
		conferenceRegistrationPageFactory=new ConferenceRegistrationPageFactory(driver);
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/ConferenceRegistartion.html");
	}

	@When("^user enters all valid data$")
	public void user_enters_all_valid_data() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPeopleAttend("2");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPlotNo("14");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setAreaName("hinjawadi");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCity("Pune");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setState("Maharashtra");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setNonMemberRadio();Thread.sleep(1000);
	}

	@When("^user clicks next link$")
	public void user_clicks_next_link() throws Throwable {
		conferenceRegistrationPageFactory.setNextLink();
	}

	@Then("^user will get alert msg$")
	public void user_will_get_alert_msg() throws Throwable {
		String alertMessage = driver.switchTo().alert().getText();
		Thread.sleep(1000);
		driver.switchTo().alert().accept();
		System.out.println("alert captured:-------------" + alertMessage);
	}

	@Then("^user will navigate to payment page$")
	public void user_will_navigate_to_payment_page() throws Throwable {
		driver.navigate().to(driver.getCurrentUrl());
	}
	@When("^user enters all valid data in payment page$")
	public void user_enters_all_valid_data_in_payment_page() throws Throwable {
		conferenceRegistrationPageFactory.setCardHolderName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setDebitCardNo("99032642634");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCvv("963");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setExpiryMonth("08");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setExpiryYear("2023");Thread.sleep(1000);

	}

	@When("^user clicks payment button$")
	public void user_clicks_payment_button() throws Throwable {
		conferenceRegistrationPageFactory.setPaymentButton();Thread.sleep(1000);
	}

	@When("^user leaves firstname blank$")
	public void user_leaves_firstname_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("");Thread.sleep(1000);
	}
	@When("^user leaves lastname blank$")
	public void user_leaves_lastname_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("");Thread.sleep(1000);
	}
	@When("^user leaves email blank$")
	public void user_leaves_email_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("");Thread.sleep(1000);
	}

	@When("^user gives invalid email id$")
	public void user_gives_invalid_email_id() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("goika@.com");Thread.sleep(1000);
	}
	@When("^user leaves phone no blank$")
	public void user_leaves_phone_no_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("");Thread.sleep(1000);
	}

	@When("^user enters incorrect phone format and clicks the button$")
	public void user_enters_incorrect_phone_format_and_clicks_the_button(DataTable arg1) throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		List<String> phoneNoList = arg1.asList(String.class);
		conferenceRegistrationPageFactory.setNextLink();Thread.sleep(1000);
		for(int i=0; i<phoneNoList.size(); i++) {
			if(Pattern.matches("^[7-9]{1}[0-9]{9}$", phoneNoList.get(i))) 
				System.out.println("***** Matched" + phoneNoList.get(i) + "*****");
			else 
				System.out.println("***** NOT Matched" + phoneNoList.get(i) + "*****");
		}
	}
	@When("^user leaves people no blank$")
	public void user_leaves_people_no_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
	}
	@When("^user leaves plot no blank$")
	public void user_leaves_plot_no_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPeopleAttend("2");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPlotNo("");Thread.sleep(1000);
	}
	@When("^user leaves area name blank$")
	public void user_leaves_area_name_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPeopleAttend("2");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPlotNo("14");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setAreaName("");Thread.sleep(1000);
	}
	@When("^user leaves city blank$")
	public void user_leaves_city_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPeopleAttend("2");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPlotNo("14");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setAreaName("hinjawadi");Thread.sleep(1000);
	}

	@When("^user leaves state blank$")
	public void user_leaves_state_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPeopleAttend("2");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPlotNo("14");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setAreaName("hinjawadi");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCity("Pune");Thread.sleep(1000);
	}
	@When("^user leaves membership blank$")
	public void user_leaves_membership_blank() throws Throwable {
		conferenceRegistrationPageFactory.setFirstName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setLastName("ankani");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setEmail("gopika@gmail.com");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPhoneNo("8985565739");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPeopleAttend("2");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setPlotNo("14");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setAreaName("hinjawadi");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCity("Pune");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setState("Maharashtra");Thread.sleep(1000);
	}
	
	@When("^user leaves cardholder name blank$")
	public void user_leaves_cardholder_name_blank() throws Throwable {
	    conferenceRegistrationPageFactory.setCardHolderName("");Thread.sleep(1000);
	}
	@When("^user leaves debit card number blank$")
	public void user_leaves_debit_card_number_blank() throws Throwable {
		conferenceRegistrationPageFactory.setCardHolderName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setDebitCardNo("");Thread.sleep(1000);
	}
	@When("^user leaves cvv blank$")
	public void user_leaves_cvv_blank() throws Throwable {
		conferenceRegistrationPageFactory.setCardHolderName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setDebitCardNo("99032642634");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCvv("");Thread.sleep(1000);
	}
	@When("^user leaves expiry month blank$")
	public void user_leaves_expiry_month_blank() throws Throwable {
		conferenceRegistrationPageFactory.setCardHolderName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setDebitCardNo("99032642634");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCvv("963");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setExpiryMonth("");Thread.sleep(1000);
	}

	@When("^user leaves expiry year blank$")
	public void user_leaves_expiry_year_blank() throws Throwable {
		conferenceRegistrationPageFactory.setCardHolderName("gopika");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setDebitCardNo("99032642634");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setCvv("963");Thread.sleep(1000);
		conferenceRegistrationPageFactory.setExpiryMonth("08");Thread.sleep(1000);
	}
	
	@After
	public void closeBrowser() {
		driver.close();
	}
}
