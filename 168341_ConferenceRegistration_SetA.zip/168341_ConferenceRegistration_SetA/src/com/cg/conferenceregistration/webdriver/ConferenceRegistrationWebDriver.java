package com.cg.conferenceregistration.webdriver;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class ConferenceRegistrationWebDriver {
	static WebDriver driver;
	static String alertMessage;
	public static void main(String[] args) {
		String driverPath = "D:\\gankani_GopaKumari_Ankani\\BDD\\Selenium\\chromedriver_win32\\";
		System.setProperty("webdriver.chrome.driver", driverPath+"chromedriver.exe");	
		driver = new ChromeDriver();
		driver.get("file:///D:/Web%20Pages%20Conference%20Registration/ConferenceRegistartion.html");
		//for Title of web page
		System.out.println("Title is: "+driver.getTitle());
		
		try {
			//for FirstName
			driver.findElement(By.id("txtFirstName")).sendKeys("");
			Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			//capture the alert
			callAlert();
			//enter firstName
			driver.findElement(By.id("txtFirstName")).sendKeys("gopika");
			Thread.sleep(1000);
			//for lastname
			driver.findElement(By.id("txtLastName")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			driver.findElement(By.id("txtLastName")).sendKeys("ankani");Thread.sleep(1000);
			//for blank email
			driver.findElement(By.id("txtEmail")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for invalid email
			driver.findElement(By.id("txtEmail")).sendKeys("gaho2dj");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for valid email
			driver.findElement(By.id("txtEmail")).clear();
			driver.findElement(By.id("txtEmail")).sendKeys("gopakumari.ankani@gmail.com");Thread.sleep(1000);
			//for blank phone no
			driver.findElement(By.id("txtPhone")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for invalid phone no
			driver.findElement(By.id("txtPhone")).sendKeys("2132432");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for valid phone no
			driver.findElement(By.id("txtPhone")).clear();
			driver.findElement(By.id("txtPhone")).sendKeys("8985565739");Thread.sleep(1000);
			//for not selecting no of people
			Select peopledropDown=new Select(driver.findElement(By.name("size")));
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//select by index
			peopledropDown.selectByIndex(1);Thread.sleep(1000);
			//for blank address
			driver.findElement(By.xpath(".//*[@id='txtAddress1']")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for giving address
			driver.findElement(By.xpath(".//*[@id='txtAddress1']")).sendKeys("14");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for blank area name
			driver.findElement(By.id("txtAddress2")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for area name
			driver.findElement(By.id("txtAddress2")).sendKeys("hinjawadi");Thread.sleep(1000);
			//for not selecting city
			Select citydropDown=new Select(driver.findElement(By.name("city")));
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//select city
			citydropDown.selectByVisibleText("Pune");
			//for not selecting state
			Select statedropDown=new Select(driver.findElement(By.name("state")));
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//select state
			statedropDown.selectByIndex(2);
			//for not selecting member status
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			//for member status
			driver.findElement(By.xpath("html/body/form/table/tbody/tr[13]/td[2]/input")).click();
			driver.findElement(By.linkText("Next")).click();Thread.sleep(1000);
			callAlert();
			System.out.println("navigated to payment page");
			//for payment page
			driver.navigate().to(driver.getCurrentUrl());
			//for blank card holder name
			driver.findElement(By.id("txtCardholderName")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.id("btnPayment")).click();Thread.sleep(1000);
			callAlert();
			//enter card holder name
			driver.findElement(By.id("txtCardholderName")).sendKeys("Gopa kumari");Thread.sleep(1000);
			
			//for blank debit card number 
			driver.findElement(By.id("txtDebit")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.id("btnPayment")).click();Thread.sleep(1000);
			callAlert();
			//enter debit card number
			driver.findElement(By.id("txtDebit")).sendKeys("4636748671446");Thread.sleep(1000);
			
			//for blank cvv
			driver.findElement(By.id("txtCvv")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.id("btnPayment")).click();Thread.sleep(1000);
			callAlert();
			//enter cvv
			driver.findElement(By.id("txtCvv")).sendKeys("258");Thread.sleep(1000);
			
			//for blank expiry month
			driver.findElement(By.id("txtMonth")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.id("btnPayment")).click();Thread.sleep(1000);
			callAlert();
			//enter expiry month
			driver.findElement(By.id("txtMonth")).sendKeys("08");Thread.sleep(1000);
			
			//for blank expiry year
			driver.findElement(By.id("txtYear")).sendKeys("");Thread.sleep(1000);
			driver.findElement(By.id("btnPayment")).click();Thread.sleep(1000);
			callAlert();
			//enter expiry year
			driver.findElement(By.id("txtYear")).sendKeys("2023");Thread.sleep(1000);
			driver.findElement(By.id("btnPayment")).click();Thread.sleep(1000);
			callAlert();
			driver.close();
		} 
		catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	public static void callAlert(){
		String alertMessage= driver.switchTo().alert().getText();
		System.out.println("alert message captured--------------------"+alertMessage);		
		driver.switchTo().alert().accept();

	}
	
}
