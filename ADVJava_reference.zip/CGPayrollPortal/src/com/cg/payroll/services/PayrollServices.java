package com.cg.payroll.services;

import java.util.List;

import com.cg.payroll.beans.*;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;

public interface PayrollServices {
	int acceptAssociateDetails(Associate associate);
	
	float calculateNetSalary(int associateId)throws AssociateDetailsNotFoundException;
	Associate getAsscoiateDetails(int associateId)throws AssociateDetailsNotFoundException;
	
	List<Associate> getAllAssociateDetails();

}
