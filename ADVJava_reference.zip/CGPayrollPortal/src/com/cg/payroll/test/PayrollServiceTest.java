package com.cg.payroll.test;

import org.junit.Before;
import org.junit.BeforeClass;
import org.junit.Test;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.daoservices.AssociateDAOImpl;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

import java.beans.Statement;
import java.sql.SQLException;
import java.util.ArrayList;

import javax.activation.DataSource;

import org.junit.After;
import org.junit.AfterClass;
import org.junit.Assert;

public class PayrollServiceTest {
	public static PayrollServices payrollServices;
	public static AssociateDAO associateDao;
	@BeforeClass
	public static void setUpTestEnv() {
		payrollServices=new PayrollServicesImpl();
		associateDao=new AssociateDAOImpl();
	}
	@Before
	public void setUpTestData() {
		Associate associate1=new Associate(200000, "gopi", "ankani","password", "java trainee", "analyst", "HAHI27979", "gopi@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(100086699, "HDFC", "hdfc997"));
		Associate associate2=new Associate(190000, "sadhik", "shaik","password", "java trainee", "analyst", "HSD97979", "sadhik@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(10008808, "HDFC", "hdfc997"));
		payrollServices.acceptAssociateDetails(associate1);
		payrollServices.acceptAssociateDetails(associate2);
	}
	@Test
	public void testAcceptAssociateDetailsForValidData() {
		int expectedAssociateId=103;
		Associate associate=new Associate(190000, "sadhik", "shaik","password", "java trainee", "analyst", "HSD97979", "sadhik@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(10008808, "HDFC", "hdfc997"));
		int actualAssociateId=payrollServices.acceptAssociateDetails(associate);
		Assert.assertEquals(expectedAssociateId, actualAssociateId);
	}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testGetAssociateDataForInvalidAssoiciateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAsscoiateDetails(179);
	}
	@Test
	public void testGetAssociateDataForValidAssociateId()throws AssociateDetailsNotFoundException{
		Associate expectedAssociate=new Associate(190000, "sadhik", "shaik","password", "java trainee", "analyst", "HSD97979", "sadhik@gmail.com", 
				new Salary(20000, 2000, 3000), new BankDetails(10008808, "HDFC", "hdfc997"));
		Associate actualAssociate=payrollServices.getAsscoiateDetails(102);
		Assert.assertEquals(expectedAssociate, actualAssociate);
		}
	@Test(expected=AssociateDetailsNotFoundException.class)
	public void testCalcualteNetSalaryForInvalidAssociateId()throws AssociateDetailsNotFoundException{
		payrollServices.getAsscoiateDetails(179);
	}
	@Test
	public void testCalcualteNetSalaryForvalidAssociateId()throws AssociateDetailsNotFoundException{
		float expectedNetSalary=33666.0f;
		float actualNetSalary=payrollServices.calculateNetSalary(102);
		Assert.assertEquals(expectedNetSalary, actualNetSalary, 500 );
	}
	@Test
	public void testForGetAllAssociateDetails() {
		ArrayList<Associate> expectedAssociateList=new ArrayList<>(associateDao.findAll());
		ArrayList<Associate> actualAssociateList=(ArrayList<Associate>) payrollServices.getAllAssociateDetails();
		Assert.assertEquals(expectedAssociateList, actualAssociateList);
	}
	@After
	public void tearDownTestData() {
	}
	@AfterClass
	public static void tearDownTestEnv() {
		payrollServices=null;
		associateDao=null;
	}
	
	

}

