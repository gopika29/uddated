package com.cg.payroll.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;


@WebServlet("/calculateSalary")
public class CalaculateSalaryServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices=new PayrollServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Associate associate=payrollServices.getAsscoiateDetails(Integer.parseInt(request.getParameter("associateId")));
			payrollServices.calculateNetSalary(associate.getAssociateID());
			RequestDispatcher dispatcher=request.getRequestDispatcher("calculateSalary.jsp");
			request.setAttribute("associate",associate);
			dispatcher.forward(request, response);
		} catch (NumberFormatException | AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
	}

}
