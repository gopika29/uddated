package com.cg.payroll.controller;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
import com.cg.payroll.services.PayrollServices;
import com.cg.payroll.services.PayrollServicesImpl;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	PayrollServices payrollServices=new PayrollServicesImpl();
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		int associateId=Integer.parseInt(request.getParameter("associateId"));
		String password=request.getParameter("password");
		Associate associate = null;
		try {
			associate = payrollServices.getAsscoiateDetails(associateId);
		} catch (AssociateDetailsNotFoundException e) {
			e.printStackTrace();
		}
		RequestDispatcher dispatcher=null;
		if(associateId==associate.getAssociateID()&&password.equals(associate.getPassword())) {
		dispatcher=request.getRequestDispatcher("loginPage.jsp");
		request.setAttribute("success","login success");
		dispatcher.forward(request, response);
		}
		else {
			dispatcher=request.getRequestDispatcher("loginPage.jsp");
			request.setAttribute("error","Associate id or password or wrong");
			dispatcher.forward(request, response);
		}
	}

}
