/*for (var i = 0; i < 10; i++) {
	document.write("Hello World <br />");
	console.log("console output");}*/
	function addNumbers(){
		var n1=parseInt(document.mathFrm.num1.value);
		var n2=parseInt(document.mathFrm.num2.value);
		document.mathFrm.ans.value=n1+n2;
	}
	function doWork(){
		
	}
