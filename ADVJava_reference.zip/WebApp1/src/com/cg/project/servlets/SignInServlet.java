package com.cg.project.servlets;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.project.bean.UserBean;

/**
 * Servlet implementation class SignInServlet
 */
@WebServlet("/SignInServlet")
public class SignInServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
 
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String name=request.getParameter("Name");
		String password=request.getParameter("paswd");
		long phone=Long.parseLong(request.getParameter("phone"));
		String gender=request.getParameter("gender");
		String email=request.getParameter("email");
		String [] courses=request.getParameterValues("course");
		String qualification=request.getParameter("qualification");
		List<String> courseList=new ArrayList<>(Arrays.asList(courses));
		UserBean bean=new UserBean(password, name, gender, email, qualification, courseList, phone);
		RequestDispatcher dispatcher=request.getRequestDispatcher("signInDetailsPage.jsp");
		request.setAttribute("bean", bean);
		dispatcher.forward(request, response);
	}

}
