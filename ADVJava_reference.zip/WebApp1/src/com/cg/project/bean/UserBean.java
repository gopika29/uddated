package com.cg.project.bean;

import java.util.List;

public class UserBean {
	private int associateId;
	private String password,name,gender,email,qualification;
	private List<String> courses;
	private long phone;
	
	public UserBean() {
	}
	public UserBean(int associateId, String password) {
		super();
		this.associateId = associateId;
		this.password = password;
	}
	
	public UserBean(String password, String name, String gender, String email, String qualification,
			List<String> courses,long phone) {
		super();
		this.password = password;
		this.name = name;
		this.gender = gender;
		this.email = email;
		this.qualification = qualification;
		this.courses = courses;
		this.phone=phone;
	}
	public long getPhone() {
		return phone;
	}
	public void setPhone(long phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getQualification() {
		return qualification;
	}
	public void setQualification(String qualification) {
		this.qualification = qualification;
	}
	public List<String> getCourses() {
		return courses;
	}
	public void setCourses(List<String> courses) {
		this.courses = courses;
	}
	public int getAssociateId() {
		return associateId;
	}
	public void setAssociateId(int associateId) {
		this.associateId = associateId;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	
	
}
