package com.cg.dao;

public class ConsumerDaoImpl implements ConusumerDao{

}
