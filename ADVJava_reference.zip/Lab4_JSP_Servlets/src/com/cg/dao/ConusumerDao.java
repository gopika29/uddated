package com.cg.dao;

public interface ConusumerDao {

}
